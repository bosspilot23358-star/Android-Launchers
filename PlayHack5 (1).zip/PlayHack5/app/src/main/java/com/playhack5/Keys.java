package com.playhack5;

import android.os.SystemClock;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;

/** Единая раскладка: клавиатура, пульт, геймпад (PS/Xbox-раскладка Android), мышь. */
final class Keys {
    static final int LEFT = 1, RIGHT = 2, UP = 3, DOWN = 4, OK = 5, BACK = 6, OPTIONS = 7, PREV = 8, NEXT = 9;

    private Keys() {
    }

    static int map(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                return LEFT;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                return RIGHT;
            case KeyEvent.KEYCODE_DPAD_UP:
                return UP;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                return DOWN;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
            case KeyEvent.KEYCODE_SPACE:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                return OK;
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_BUTTON_B:
            case KeyEvent.KEYCODE_ESCAPE:
                return BACK;
            case KeyEvent.KEYCODE_BUTTON_Y:
            case KeyEvent.KEYCODE_BUTTON_X:
            case KeyEvent.KEYCODE_BUTTON_START:
            case KeyEvent.KEYCODE_MENU:
                return OPTIONS;
            case KeyEvent.KEYCODE_BUTTON_L1:
            case KeyEvent.KEYCODE_PAGE_UP:
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                return PREV;
            case KeyEvent.KEYCODE_BUTTON_R1:
            case KeyEvent.KEYCODE_PAGE_DOWN:
            case KeyEvent.KEYCODE_MEDIA_NEXT:
            case KeyEvent.KEYCODE_TAB:
                return NEXT;
            default:
                return 0;
        }
    }

    /** Левый стик геймпада → LEFT/RIGHT/UP/DOWN с ограничением частоты. last[0] — время прошлого срабатывания. */
    static int stick(MotionEvent e, long[] last) {
        if ((e.getSource() & InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK
                || e.getAction() != MotionEvent.ACTION_MOVE) return 0;
        float x = e.getAxisValue(MotionEvent.AXIS_X);
        float y = e.getAxisValue(MotionEvent.AXIS_Y);
        long now = SystemClock.uptimeMillis();
        if (Math.abs(x) > 0.65f && Math.abs(x) >= Math.abs(y) && now - last[0] > 170) {
            last[0] = now;
            return x > 0 ? RIGHT : LEFT;
        }
        if (Math.abs(y) > 0.75f && now - last[0] > 200) {
            last[0] = now;
            return y > 0 ? DOWN : UP;
        }
        return 0;
    }
}
