package com.playhack5;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.widget.TextView;

/** Лёгкие самодельные View: без теней, размытия и лишних слоёв. */
final class Views {
    private Views() {
    }

    // ---------------------------------------------------------------- Плитка игры
    static final class TileView extends View {
        private final int size;
        private final float radius;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint ph = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dim = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final RectF ringRect = new RectF();
        private boolean hasBmp;
        boolean selected;

        TileView(Context c, int size) {
            super(c);
            this.size = size;
            this.radius = size * 0.14f;
            ph.setColor(0xFF1B2540);
            dim.setColor(0x66000000);
            ring.setStyle(Paint.Style.STROKE);
            ring.setColor(Color.WHITE);
            ring.setStrokeWidth(Math.max(2f, size * 0.03f));
            setFocusable(false);
            setClickable(true);
        }

        void setBitmap(Bitmap b) {
            BitmapShader sh = new BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            Matrix m = new Matrix();
            float sc = (float) size / b.getWidth();
            m.setScale(sc, sc);
            sh.setLocalMatrix(m);
            fill.setShader(sh);
            hasBmp = true;
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            rect.set(0, 0, w, h);
            float in = ring.getStrokeWidth() / 2f;
            ringRect.set(in, in, w - in, h - in);
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawRoundRect(rect, radius, radius, hasBmp ? fill : ph);
            if (!selected) c.drawRoundRect(rect, radius, radius, dim);
            else c.drawRoundRect(ringRect, radius, radius, ring);
        }
    }

    // ---------------------------------------------------------------- Фон
    static final class BackgroundView extends View {
        private final Paint linear = new Paint();
        private final Paint glow = new Paint();
        private int tint = IconCache.DEFAULT_TINT;
        private ValueAnimator anim;

        BackgroundView(Context c) {
            super(c);
        }

        void setTint(int target, boolean animate) {
            if (anim != null) anim.cancel();
            if (!animate || getWidth() == 0) {
                tint = target;
                rebuild();
                invalidate();
                return;
            }
            anim = ValueAnimator.ofObject(new ArgbEvaluator(), tint, target);
            anim.setDuration(350);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    tint = (Integer) a.getAnimatedValue();
                    rebuild();
                    invalidate();
                }
            });
            anim.start();
        }

        private static int scale(int c, float k) {
            return Color.rgb((int) (Color.red(c) * k), (int) (Color.green(c) * k), (int) (Color.blue(c) * k));
        }

        private void rebuild() {
            int w = getWidth(), h = getHeight();
            if (w == 0) return;
            linear.setShader(new LinearGradient(0, 0, 0, h,
                    new int[]{tint, scale(tint, 0.45f), 0xFF02050C},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            float[] hsv = new float[3];
            Color.colorToHSV(tint, hsv);
            hsv[1] *= 0.8f;
            hsv[2] = Math.min(1f, hsv[2] * 1.7f);
            int light = Color.HSVToColor(0x70, hsv);
            glow.setShader(new RadialGradient(w * 0.78f, h * 0.18f, w * 0.7f,
                    light, light & 0x00FFFFFF, Shader.TileMode.CLAMP));
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            rebuild();
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawRect(0, 0, getWidth(), getHeight(), linear);
            c.drawRect(0, 0, getWidth(), getHeight(), glow);
        }
    }

    // ---------------------------------------------------------------- Вкладка
    static final class TabView extends TextView {
        private final Paint ul = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean on;

        TabView(Context c) {
            super(c);
            ul.setColor(Color.WHITE);
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        }

        void setOn(boolean v) {
            on = v;
            setTextColor(v ? 0xFFFFFFFF : 0x88FFFFFF);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            if (on) {
                float y = getHeight() - getPaddingBottom() * 0.7f;
                c.drawRoundRect(new RectF(getWidth() * 0.18f, y, getWidth() * 0.82f, y + Math.max(2f, getHeight() * 0.05f)),
                        4, 4, ul);
            }
        }
    }

    // ---------------------------------------------------------------- Кнопка «Играть»
    static final class PlayButton extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tx = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int h;
        private String label = "Играть";
        private int w;

        PlayButton(Context c, int height, float textPx) {
            super(c);
            h = height;
            bg.setColor(0xFFFFFFFF);
            tx.setColor(0xFF0A0F1E);
            tx.setTextSize(textPx);
            tx.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            setClickable(true);
            setFocusable(false);
        }

        void setLabel(String s) {
            label = s;
            requestLayout();
            invalidate();
        }

        @Override
        protected void onMeasure(int wm, int hm) {
            w = (int) (h * 1.9f + tx.measureText(label));
            setMeasuredDimension(w, h);
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawRoundRect(new RectF(0, 0, w, h), h / 2f, h / 2f, bg);
            float ts = h * 0.26f;
            float tx0 = h * 0.62f;
            Path t = new Path();
            t.moveTo(tx0, h / 2f - ts);
            t.lineTo(tx0 + ts * 1.6f, h / 2f);
            t.lineTo(tx0, h / 2f + ts);
            t.close();
            c.drawPath(t, tx);
            c.drawText(label, tx0 + ts * 2.4f, h / 2f + tx.getTextSize() * 0.35f, tx);
        }
    }

    // ---------------------------------------------------------------- Заставка
    static final class SplashView extends View {
        private final Paint a = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint b = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float k;

        SplashView(Context c, float textPx) {
            super(c);
            a.setTextSize(textPx);
            a.setColor(Color.WHITE);
            a.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            b.setTextSize(textPx * 1.25f);
            b.setColor(0xFF3D8BFF);
            b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            setClickable(true);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            ValueAnimator v = ValueAnimator.ofFloat(0f, 1f);
            v.setDuration(600);
            v.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator an) {
                    k = (Float) an.getAnimatedValue();
                    invalidate();
                }
            });
            v.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawColor(0xFF000000);
            String s1 = "PlayHack", s2 = "5";
            float w1 = a.measureText(s1), w2 = b.measureText(s2);
            float x = (getWidth() - w1 - w2) / 2f;
            float y = getHeight() / 2f + a.getTextSize() * 0.35f;
            int al = (int) (255 * k);
            a.setAlpha(al);
            b.setAlpha(al);
            c.drawText(s1, x, y, a);
            c.drawText(s2, x + w1, y, b);
        }
    }
}
