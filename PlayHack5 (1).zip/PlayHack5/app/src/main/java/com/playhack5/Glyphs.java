package com.playhack5;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;

/** Иконки, нарисованные кодом (без файлов-картинок). */
final class Glyphs {
    static final int WIFI = 0, BT = 1, DISPLAY = 2, GEAR = 3, HOME = 4, BOLT = 5, INFO = 6,
            VIDEO = 7, MUSIC = 8, PHOTO = 9, FOLDER = 10, FILE = 11, STORAGE = 12, COUNT = 13;

    private static final int[][] COLORS = {
            {0xFF2B7BE4, 0xFF0B3C8C}, {0xFF4757D6, 0xFF1C2478}, {0xFF14A38B, 0xFF0A5C63},
            {0xFF607D8B, 0xFF263238}, {0xFF9C4DD0, 0xFF4A1A7A}, {0xFFF5A623, 0xFFB4531A},
            {0xFF3CA6D8, 0xFF14507A},
            {0xFFE5484D, 0xFF8C1D2C}, {0xFFE04F9B, 0xFF7B1F5C}, {0xFF3FB68B, 0xFF1C6B58},
            {0xFFE8B04B, 0xFF9C6A1E}, {0xFF78909C, 0xFF37474F}, {0xFF4F8FD6, 0xFF1F3F7A}};

    private Glyphs() {
    }

    private static void poly(Path p, float s, float... xy) {
        p.reset();
        for (int i = 0; i < xy.length; i += 2) {
            if (i == 0) p.moveTo(xy[i] * s, xy[i + 1] * s);
            else p.lineTo(xy[i] * s, xy[i + 1] * s);
        }
    }

    static Bitmap make(int g, int size) {
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, size, size, COLORS[g][0], COLORS[g][1], Shader.TileMode.CLAMP));
        c.drawRect(0, 0, size, size, p);
        p.setShader(null);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(size * 0.055f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        float s = size;
        float cx = s * 0.5f, cy = s * 0.5f;
        Path path = new Path();
        switch (g) {
            case WIFI: {
                float wy = s * 0.68f;
                float[] radii = {0.14f, 0.27f, 0.40f};
                for (float r : radii) {
                    float rr = r * s;
                    c.drawArc(new RectF(cx - rr, wy - rr, cx + rr, wy + rr), 225, 90, false, p);
                }
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, wy, s * 0.035f, p);
                break;
            }
            case BT:
                poly(path, s, 0.3f, 0.35f, 0.7f, 0.65f, 0.5f, 0.8f, 0.5f, 0.2f, 0.7f, 0.35f, 0.3f, 0.65f);
                c.drawPath(path, p);
                break;
            case DISPLAY:
                c.drawRoundRect(new RectF(s * 0.2f, s * 0.28f, s * 0.8f, s * 0.64f), s * 0.04f, s * 0.04f, p);
                c.drawLine(cx, s * 0.64f, cx, s * 0.76f, p);
                c.drawLine(s * 0.36f, s * 0.76f, s * 0.64f, s * 0.76f, p);
                break;
            case GEAR:
                c.drawCircle(cx, cy, s * 0.13f, p);
                c.drawCircle(cx, cy, s * 0.22f, p);
                for (int k = 0; k < 8; k++) {
                    double a = k * Math.PI / 4;
                    float cos = (float) Math.cos(a), sin = (float) Math.sin(a);
                    c.drawLine(cx + cos * s * 0.22f, cy + sin * s * 0.22f,
                            cx + cos * s * 0.32f, cy + sin * s * 0.32f, p);
                }
                break;
            case HOME:
                poly(path, s, 0.5f, 0.22f, 0.8f, 0.48f, 0.7f, 0.48f, 0.7f, 0.78f, 0.3f, 0.78f, 0.3f, 0.48f, 0.2f, 0.48f);
                path.close();
                c.drawPath(path, p);
                break;
            case BOLT:
                p.setStyle(Paint.Style.FILL);
                poly(path, s, 0.56f, 0.18f, 0.30f, 0.54f, 0.48f, 0.54f, 0.42f, 0.82f, 0.70f, 0.44f, 0.52f, 0.44f);
                path.close();
                c.drawPath(path, p);
                break;
            case VIDEO:
                c.drawRoundRect(new RectF(s * 0.2f, s * 0.28f, s * 0.8f, s * 0.72f), s * 0.05f, s * 0.05f, p);
                p.setStyle(Paint.Style.FILL);
                poly(path, s, 0.43f, 0.40f, 0.62f, 0.50f, 0.43f, 0.60f);
                path.close();
                c.drawPath(path, p);
                break;
            case MUSIC:
                c.drawLine(s * 0.60f, s * 0.24f, s * 0.60f, s * 0.66f, p);
                c.drawLine(s * 0.60f, s * 0.24f, s * 0.76f, s * 0.36f, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(s * 0.50f, s * 0.68f, s * 0.10f, p);
                break;
            case PHOTO:
                c.drawRoundRect(new RectF(s * 0.2f, s * 0.26f, s * 0.8f, s * 0.74f), s * 0.05f, s * 0.05f, p);
                poly(path, s, 0.2f, 0.68f, 0.42f, 0.5f, 0.56f, 0.62f, 0.66f, 0.54f, 0.8f, 0.68f);
                c.drawPath(path, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(s * 0.36f, s * 0.40f, s * 0.045f, p);
                break;
            case FOLDER:
                poly(path, s, 0.2f, 0.3f, 0.42f, 0.3f, 0.48f, 0.38f, 0.8f, 0.38f, 0.8f, 0.7f, 0.2f, 0.7f);
                path.close();
                c.drawPath(path, p);
                break;
            case FILE:
                poly(path, s, 0.3f, 0.22f, 0.56f, 0.22f, 0.72f, 0.38f, 0.72f, 0.78f, 0.3f, 0.78f);
                path.close();
                c.drawPath(path, p);
                poly(path, s, 0.56f, 0.22f, 0.56f, 0.38f, 0.72f, 0.38f);
                c.drawPath(path, p);
                break;
            case STORAGE:
                c.drawRoundRect(new RectF(s * 0.2f, s * 0.34f, s * 0.8f, s * 0.66f), s * 0.05f, s * 0.05f, p);
                c.drawLine(s * 0.28f, s * 0.58f, s * 0.5f, s * 0.58f, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(s * 0.68f, s * 0.54f, s * 0.035f, p);
                break;
            default: // INFO
                c.drawCircle(cx, cy, s * 0.3f, p);
                c.drawLine(cx, s * 0.46f, cx, s * 0.68f, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, s * 0.34f, s * 0.035f, p);
                break;
        }
        return b;
    }
}
