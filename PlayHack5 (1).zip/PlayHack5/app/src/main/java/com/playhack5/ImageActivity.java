package com.playhack5;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.media.ExifInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.File;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Просмотр фото (JPG, PNG, WebP, BMP, GIF, HEIC/AVIF — что умеет система).
 * ←/→ или L1/R1 — листать, A/Enter/↑ — приблизить (потом стрелки двигают кадр), B/Esc — назад/сброс зума,
 * Y/Menu — слайдшоу. Мышь: колесо — зум, перетаскивание — сдвиг, клик по краям — листать.
 */
public class ImageActivity extends Activity {
    private Ui ui;
    private Photo pv;
    private List<String> list;
    private int idx;
    private int gen;
    private boolean slide;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler h = new Handler(Looper.getMainLooper());
    private final long[] axisLast = new long[1];
    private float downX, downY, lastX, lastY;
    private boolean moved;

    private final Runnable slideTask = new Runnable() {
        @Override
        public void run() {
            if (!slide) return;
            go(1, true);
            h.postDelayed(this, 5000);
        }
    };

    // ------------------------------------------------------------------ вид
    private final class Photo extends View {
        Bitmap bmp;
        float zoom = 1f, panX, panY;
        String info = "", hint = "";
        long infoUntil;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint shade = new Paint();
        private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final TextPaint tp2 = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final Matrix m = new Matrix();

        Photo(Context c) {
            super(c);
            tp.setColor(0xFFFFFFFF);
            tp.setTextSize(ui.px(4.4f, 14));
            tp2.setColor(0xB3FFFFFF);
            tp2.setTextSize(ui.px(3.6f, 11));
        }

        float fit() {
            return Math.min((float) getWidth() / bmp.getWidth(), (float) getHeight() / bmp.getHeight());
        }

        void setBitmap(Bitmap b) {
            bmp = b;
            zoom = 1f;
            panX = panY = 0;
            invalidate();
        }

        void setZoom(float z) {
            zoom = Math.max(1f, Math.min(8f, z));
            clampPan();
            invalidate();
        }

        void move(int dx, int dy) {
            float step = Math.min(getWidth(), getHeight()) * 0.18f;
            panX -= dx * step;
            panY -= dy * step;
            clampPan();
            invalidate();
        }

        void drag(float dx, float dy) {
            panX += dx;
            panY += dy;
            clampPan();
            invalidate();
        }

        void clampPan() {
            if (bmp == null) return;
            float s = fit() * zoom;
            float mx = Math.max(0, (bmp.getWidth() * s - getWidth()) / 2f);
            float my = Math.max(0, (bmp.getHeight() * s - getHeight()) / 2f);
            panX = Math.max(-mx, Math.min(mx, panX));
            panY = Math.max(-my, Math.min(my, panY));
        }

        void showInfo(String s, String hnt) {
            info = s;
            hint = hnt;
            infoUntil = SystemClock.uptimeMillis() + 3000;
            invalidate();
            postInvalidateDelayed(3100);
        }

        @Override
        protected void onSizeChanged(int w, int hh, int ow, int oh) {
            shade.setShader(new LinearGradient(0, hh * 0.78f, 0, hh, 0, 0xCC000000, Shader.TileMode.CLAMP));
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawColor(0xFF000000);
            int w = getWidth(), hh = getHeight();
            if (bmp != null) {
                float s = fit() * zoom;
                m.setScale(s, s);
                m.postTranslate((w - bmp.getWidth() * s) / 2f + panX, (hh - bmp.getHeight() * s) / 2f + panY);
                c.drawBitmap(bmp, m, p);
            }
            if (SystemClock.uptimeMillis() < infoUntil) {
                c.drawRect(0, hh * 0.78f, w, hh, shade);
                float pad = 5 * ui.u;
                String t = TextUtils.ellipsize(info, tp, w - 2 * pad, TextUtils.TruncateAt.MIDDLE).toString();
                c.drawText(t, pad, hh - 8.5f * ui.u, tp);
                c.drawText(hint, pad, hh - 3.5f * ui.u, tp2);
            }
        }
    }

    // ------------------------------------------------------------------ жизненный цикл
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ui = new Ui(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        list = MediaUtil.playlist;
        idx = getIntent().getIntExtra("index", 0);
        if (list == null || list.isEmpty() || idx < 0 || idx >= list.size()) {
            finish();
            return;
        }
        pv = new Photo(this);
        pv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                return touch(e);
            }
        });
        setContentView(pv);
        load(idx, true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        slide = false;
        h.removeCallbacksAndMessages(null);
        io.shutdownNow();
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) Ui.immersive(this);
    }

    // ------------------------------------------------------------------ загрузка
    private void load(final int i, final boolean first) {
        idx = i;
        final int g = ++gen;
        final String path = list.get(i);
        io.execute(new Runnable() {
            @Override
            public void run() {
                if (g != gen) return;
                final Bitmap b = decode(path);
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        if (g != gen || isFinishing()) {
                            if (b != null) b.recycle();
                            return;
                        }
                        if (b == null) {
                            Toast.makeText(ImageActivity.this, "Не удалось открыть файл", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Bitmap old = pv.bmp;
                        pv.setBitmap(b);
                        if (old != null && old != b) old.recycle();
                        pv.showInfo((idx + 1) + "/" + list.size() + "   " + new File(path).getName(),
                                first ? "←/→ листать · OK зум · Y слайдшоу · B назад" : (slide ? "слайдшоу" : ""));
                    }
                });
            }
        });
    }

    /** Декодируем с уменьшением под экран (×2 запас на зум) — экономит память на 2 ГБ платах. */
    private Bitmap decode(String path) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int tw = ui.W * 2, th = ui.H * 2;
            int s = 1;
            while (o.outWidth / (s * 2) >= tw && o.outHeight / (s * 2) >= th) s *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = s;
            Bitmap b = BitmapFactory.decodeFile(path, o);
            if (b == null) return null;
            int rot = 0;
            try {
                int ori = new ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL);
                if (ori == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
            } catch (Exception ignored) {
            }
            if (rot != 0) {
                Matrix mt = new Matrix();
                mt.postRotate(rot);
                Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), mt, true);
                if (r != b) b.recycle();
                b = r;
            }
            return b;
        } catch (Throwable t) { // в т.ч. OutOfMemoryError на огромных файлах
            return null;
        }
    }

    // ------------------------------------------------------------------ действия
    private void go(int dir, boolean wrap) {
        int n = idx + dir;
        if (n < 0 || n >= list.size()) {
            if (!wrap) return;
            n = (n + list.size()) % list.size();
        }
        load(n, false);
    }

    private void zoomCycle() {
        float z = pv.zoom;
        pv.setZoom(z < 1.5f ? 2f : z < 3f ? 4f : 1f);
        pv.showInfo(Math.round(pv.zoom * 100) + "%", "стрелки — сдвиг · OK — ещё · B — сброс");
    }

    private void toggleSlide() {
        slide = !slide;
        h.removeCallbacks(slideTask);
        if (slide) h.postDelayed(slideTask, 5000);
        pv.showInfo(slide ? "Слайдшоу: вкл (5 с)" : "Слайдшоу: выкл", "");
    }

    private void handle(int a, int rep) {
        boolean zoomed = pv.zoom > 1.01f;
        switch (a) {
            case Keys.LEFT:
                if (zoomed) pv.move(-1, 0);
                else if (rep == 0 || rep % 4 == 0) go(-1, false);
                break;
            case Keys.RIGHT:
                if (zoomed) pv.move(1, 0);
                else if (rep == 0 || rep % 4 == 0) go(1, false);
                break;
            case Keys.UP:
                if (zoomed) pv.move(0, -1);
                else if (rep == 0) zoomCycle();
                break;
            case Keys.DOWN:
                if (zoomed) pv.move(0, 1);
                break;
            case Keys.OK:
                if (rep == 0) zoomCycle();
                break;
            case Keys.PREV:
                if (rep == 0 || rep % 4 == 0) go(-1, false);
                break;
            case Keys.NEXT:
                if (rep == 0 || rep % 4 == 0) go(1, false);
                break;
            case Keys.OPTIONS:
                if (rep == 0) toggleSlide();
                break;
            case Keys.BACK:
                if (rep == 0) {
                    if (zoomed) pv.setZoom(1f);
                    else finish();
                }
                break;
            default:
                break;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent ev) {
        int a = Keys.map(ev.getKeyCode());
        if (a == 0) return super.dispatchKeyEvent(ev);
        if (ev.getAction() == KeyEvent.ACTION_DOWN) handle(a, ev.getRepeatCount());
        return true;
    }

    /** Мышь/тач: тяните — сдвиг (при зуме), клик по левой/правой трети — листать, по центру — зум. */
    private boolean touch(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = x;
                downY = lastY = y;
                moved = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (Math.hypot(x - downX, y - downY) > 12) moved = true;
                if (moved && pv.zoom > 1.01f) pv.drag(x - lastX, y - lastY);
                lastX = x;
                lastY = y;
                return true;
            case MotionEvent.ACTION_UP:
                if (!moved) {
                    if (pv.zoom > 1.01f) zoomCycle();
                    else if (x < ui.W / 3f) go(-1, false);
                    else if (x > ui.W * 2f / 3f) go(1, false);
                    else zoomCycle();
                }
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_SCROLL) {
            float v = e.getAxisValue(MotionEvent.AXIS_VSCROLL);
            if (v != 0) {
                pv.setZoom(pv.zoom * (v > 0 ? 1.25f : 0.8f));
                pv.showInfo(Math.round(pv.zoom * 100) + "%", "");
                return true;
            }
        }
        int a = Keys.stick(e, axisLast);
        if (a != 0) {
            handle(a, 0);
            return true;
        }
        return super.onGenericMotionEvent(e);
    }
}
