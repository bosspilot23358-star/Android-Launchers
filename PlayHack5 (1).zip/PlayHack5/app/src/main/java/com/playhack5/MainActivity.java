package com.playhack5;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * PlayHack5 — лаунчер в стиле игровой консоли.
 * Управление: стрелки/D-pad — выбор, ✕/A/Enter — запуск, △/Y/Menu — опции,
 * L1/R1 (или вверх/вниз) — вкладки. Работает также с мышью и тачем.
 */
public class MainActivity extends Activity {
    private static final int TAB_GAMES = 0, TAB_APPS = 1, TAB_MEDIA = 2, TAB_SYS = 3;
    private static final int K_LEFT = 1, K_RIGHT = 2, K_UP = 3, K_DOWN = 4, K_OK = 5, K_BACK = 6,
            K_OPTIONS = 7, K_PREV = 8, K_NEXT = 9;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final SimpleDateFormat clockFmt = new SimpleDateFormat("HH:mm", Locale.getDefault());

    private Store store;
    private IconCache icons;
    private boolean lite;
    private float u, d;
    private boolean compact;
    private int W, H, tileSize, gap, padL;
    private long startedAt;

    private FrameLayout root;
    private Views.BackgroundView bg;
    private final Views.TabView[] tabViews = new Views.TabView[4];
    private TextView clock, title, sub, empty;
    private Views.PlayButton play;
    private HorizontalScrollView scroller;
    private LinearLayout row;
    private Views.SplashView splash;

    private FrameLayout panel;
    private final List<TextView> panelItems = new ArrayList<>();
    private final List<Runnable> panelActs = new ArrayList<>();
    private int panelSel;

    private List<Entry> all = new ArrayList<>();
    private final List<Entry> games = new ArrayList<>();
    private final List<Entry> apps = new ArrayList<>();
    private final List<Entry> sys = new ArrayList<>();
    private final List<Entry> media = new ArrayList<>();
    private List<Entry> cur = games;
    private final int[] selMem = new int[4];
    private final List<Views.TileView> tiles = new ArrayList<>();
    private int tab = TAB_GAMES;
    private int sel = -1;
    private long lastAxis;

    private final IconCache.Cb loadCb = new IconCache.Cb() {
        @Override
        public void done(String key, Bitmap bmp, int tint) {
            for (Views.TileView t : tiles) {
                if (key.equals(t.getTag())) t.setBitmap(bmp);
            }
            if (sel >= 0 && sel < cur.size() && cur.get(sel).key.equals(key)) bg.setTint(tint, !lite);
        }
    };

    private final BroadcastReceiver clockRx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            updateClock();
        }
    };
    private final BroadcastReceiver pkgRx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            reload();
        }
    };

    // ============================================================ жизненный цикл
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        startedAt = SystemClock.uptimeMillis();
        store = new Store(this);

        DisplayMetrics m = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(m);
        W = Math.max(m.widthPixels, m.heightPixels);
        H = Math.min(m.widthPixels, m.heightPixels);
        d = m.density;
        u = H / 100f;

        // На платах с ≤3 ГБ ОЗУ по умолчанию включаем «лёгкий режим» (без анимаций).
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        boolean small = mi.totalMem <= (3L << 30);
        lite = store.lite(small);

        compact = H <= 420; // экран вроде 480×320: только относительные размеры
        tileSize = compact ? (int) (28 * u) : (int) Math.max(28 * u, 72 * d);
        gap = (int) (3 * u);
        padL = (int) (6 * u);
        icons = new IconCache(this, tileSize, lite ? 8 * 1024 * 1024 : 14 * 1024 * 1024);

        buildUi(b == null);
        setContentView(root);
        updateClock();
        reload();
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter tf = new IntentFilter(Intent.ACTION_TIME_TICK);
        tf.addAction(Intent.ACTION_TIME_CHANGED);
        tf.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        IntentFilter pf = new IntentFilter(Intent.ACTION_PACKAGE_ADDED);
        pf.addAction(Intent.ACTION_PACKAGE_REMOVED);
        pf.addAction(Intent.ACTION_PACKAGE_REPLACED);
        pf.addDataScheme("package");
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(clockRx, tf, Context.RECEIVER_EXPORTED);
            registerReceiver(pkgRx, pf, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(clockRx, tf);
            registerReceiver(pkgRx, pf);
        }
        updateClock();
        if (!all.isEmpty()) reload(); // вернулись из игры: обновить «последние запущенные»
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            unregisterReceiver(clockRx);
            unregisterReceiver(pkgRx);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdown();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        hidePanel();
        if (i != null && i.hasCategory(Intent.CATEGORY_HOME)) {
            selMem[TAB_GAMES] = 0;
            showTab(TAB_GAMES, null);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public void onBackPressed() {
        if (panel != null) hidePanel(); // главный экран не закрываем
    }

    // ============================================================ построение UI
    private float px(float uf, float minDp) {
        return compact ? uf * u : Math.max(uf * u, minDp * d);
    }

    private void buildUi(boolean cold) {
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF02050C);

        bg = new Views.BackgroundView(this);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        // Вкладки
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Игры", "Приложения", "Медиа", "Настройки"};
        for (int i = 0; i < 4; i++) {
            Views.TabView t = new Views.TabView(this);
            t.setText(names[i]);
            t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(4.6f, 14));
            t.setPadding((int) (2 * u), (int) u, (int) (2 * u), (int) (1.6f * u));
            final int ii = i;
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    setTab(ii);
                }
            });
            tabViews[i] = t;
            tabs.addView(t);
        }
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2);
        tp.leftMargin = padL - (int) (2 * u);
        tp.topMargin = (int) (3 * u);
        root.addView(tabs, tp);

        // Часы
        clock = new TextView(this);
        clock.setTextColor(0xFFFFFFFF);
        clock.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        clock.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(4.4f, 14));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        cp.rightMargin = padL;
        cp.topMargin = (int) (4 * u);
        root.addView(clock, cp);

        // Заголовок выбранной игры
        title = new TextView(this);
        title.setTextColor(0xFFFFFFFF);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(8f, 20));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(W - 2 * padL, -2);
        hp.leftMargin = padL;
        hp.topMargin = (int) (22 * u);
        root.addView(title, hp);

        sub = new TextView(this);
        sub.setTextColor(0xB3FFFFFF);
        sub.setSingleLine(true);
        sub.setEllipsize(TextUtils.TruncateAt.END);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(4.2f, 11));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(W - 2 * padL, -2);
        sp.leftMargin = padL;
        sp.topMargin = (int) (34.5f * u);
        root.addView(sub, sp);

        play = new Views.PlayButton(this, (int) px(7f, 26), px(4f, 12));
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchSel();
            }
        });
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-2, -2);
        pp.leftMargin = padL;
        pp.topMargin = (int) (40 * u);
        root.addView(play, pp);

        // Ряд плиток
        scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroller.setClipChildren(false);
        scroller.setClipToPadding(false);
        scroller.setFocusable(false);
        row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setClipChildren(false);
        row.setPadding(padL, 0, padL, 0);
        scroller.addView(row, new FrameLayout.LayoutParams(-2, -1));
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(W, (int) (tileSize * 1.4f));
        rp.topMargin = (int) (50 * u);
        root.addView(scroller, rp);

        empty = new TextView(this);
        empty.setTextColor(0xB3FFFFFF);
        empty.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(4f, 12));
        empty.setVisibility(View.GONE);
        FrameLayout.LayoutParams ep = new FrameLayout.LayoutParams(W - 2 * padL, -2);
        ep.leftMargin = padL;
        ep.topMargin = (int) (56 * u);
        root.addView(empty, ep);

        // Подсказки
        Hints hints = new Hints(this, px(3.8f, 10), padL, new String[][]{
                {"x", "Играть"}, {"t", "Опции"}, {"b", "L1,R1", "Вкладки"}});
        FrameLayout.LayoutParams hbp = new FrameLayout.LayoutParams(W, (int) (8 * u));
        hbp.topMargin = (int) (90 * u);
        root.addView(hints, hbp);

        if (cold) {
            splash = new Views.SplashView(this, px(9f, 26));
            root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        }
    }

    private void updateClock() {
        if (clock != null) clock.setText(clockFmt.format(new Date()));
    }

    // ============================================================ данные
    private void reload() {
        io.execute(new Runnable() {
            @Override
            public void run() {
                final List<Entry> l = store.load(MainActivity.this);
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing()) return;
                        all = l;
                        rebuildLists();
                        hideSplash();
                    }
                });
            }
        });
    }

    private void hideSplash() {
        if (splash == null) return;
        final View s = splash;
        splash = null;
        long wait = Math.max(0, (lite ? 800 : 1200) - (SystemClock.uptimeMillis() - startedAt));
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                s.animate().alpha(0f).setDuration(lite ? 150 : 350).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        root.removeView(s);
                    }
                }).start();
            }
        }, wait);
    }

    private void rebuildLists() {
        String keep = (sel >= 0 && sel < cur.size()) ? cur.get(sel).key : null;
        games.clear();
        apps.clear();
        for (Entry e : all) (e.game ? games : apps).add(e);
        Collections.sort(games, new java.util.Comparator<Entry>() {
            @Override
            public int compare(Entry a, Entry b) {
                if (a.last != b.last) return a.last > b.last ? -1 : 1;
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        Collections.sort(apps, new java.util.Comparator<Entry>() {
            @Override
            public int compare(Entry a, Entry b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        buildSys();
        buildMedia();
        showTab(tab, keep);
    }

    private Entry act(String id, String label, String desc, int glyph) {
        Entry e = new Entry(Entry.ACTION);
        e.key = "act:" + id;
        e.label = label;
        e.desc = desc;
        e.glyph = glyph;
        return e;
    }

    private void buildMedia() {
        media.clear();
        media.add(act("m_video", "Видео", "Фильмы и ролики: MKV, MP4, AVI, MOV и другие форматы", Glyphs.VIDEO));
        media.add(act("m_music", "Музыка", "Аудио: MP3, FLAC, OGG, WAV, AAC и другие", Glyphs.MUSIC));
        media.add(act("m_photo", "Фото", "Изображения: JPG, PNG, WebP, GIF, BMP", Glyphs.PHOTO));
        media.add(act("m_files", "Файлы", "Обзор памяти и USB-накопителей", Glyphs.FOLDER));
    }

    private void openBrowser(int mode) {
        startActivity(new Intent(this, BrowserActivity.class).putExtra("mode", mode));
    }

    private void buildSys() {
        sys.clear();
        sys.add(act("wifi", "Wi-Fi", "Подключение к сети", Glyphs.WIFI));
        sys.add(act("bt", "Bluetooth", "Геймпады, клавиатуры, мыши", Glyphs.BT));
        sys.add(act("display", "Экран", "Разрешение и яркость", Glyphs.DISPLAY));
        sys.add(act("settings", "Системные настройки", "Все настройки Android", Glyphs.GEAR));
        sys.add(act("home", "Главный экран", "Сделать PlayHack5 главным экраном", Glyphs.HOME));
        sys.add(act("lite", lite ? "Лёгкий режим: вкл" : "Лёгкий режим: выкл",
                "Без анимаций — для слабых плат. Нажмите, чтобы переключить", Glyphs.BOLT));
        sys.add(act("about", "О PlayHack5", "Версия 1.1 · лаунчер в стиле консоли", Glyphs.INFO));
    }

    // ============================================================ вкладки и плитки
    private void setTab(int t) {
        if (t == tab) return;
        selMem[tab] = Math.max(0, sel);
        showTab(t, null);
    }

    private void tabMove(int dir) {
        setTab((tab + dir + 4) % 4);
    }

    private void showTab(int t, String keepKey) {
        tab = t;
        cur = t == TAB_GAMES ? games : t == TAB_APPS ? apps : t == TAB_MEDIA ? media : sys;
        for (int i = 0; i < 4; i++) tabViews[i].setOn(i == t);

        int idx = Math.min(selMem[t], Math.max(0, cur.size() - 1));
        if (keepKey != null) {
            for (int i = 0; i < cur.size(); i++) {
                if (cur.get(i).key.equals(keepKey)) {
                    idx = i;
                    break;
                }
            }
        }
        buildTiles();
        if (cur.isEmpty()) {
            empty.setText(t == TAB_GAMES
                    ? "Игры не найдены.\nОткройте «Приложения», выберите программу и нажмите Y (Menu), чтобы добавить её в «Игры»."
                    : "Здесь пока ничего нет.");
            empty.setVisibility(View.VISIBLE);
        } else {
            empty.setVisibility(View.GONE);
        }
        sel = -1;
        select(idx, false);
    }

    private void buildTiles() {
        row.removeAllViews();
        tiles.clear();
        for (int i = 0; i < cur.size(); i++) {
            final Entry e = cur.get(i);
            final int idx = i;
            Views.TileView t = new Views.TileView(this, tileSize);
            t.setTag(e.key);
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (idx == sel) launch(e);
                    else select(idx, true);
                }
            });
            t.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    select(idx, true);
                    showOptions();
                    return true;
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tileSize, tileSize);
            lp.rightMargin = gap;
            row.addView(t, lp);
            tiles.add(t);
            Bitmap b = icons.peek(e.key);
            if (b != null) t.setBitmap(b);
            else icons.load(e, loadCb);
        }
        scroller.scrollTo(0, 0);
    }

    private void setTileSel(Views.TileView t, boolean on, boolean anim) {
        t.selected = on;
        t.invalidate();
        float s = on ? 1.16f : 1f;
        if (lite || !anim) {
            t.setScaleX(s);
            t.setScaleY(s);
        } else {
            t.animate().scaleX(s).scaleY(s).setDuration(130).start();
        }
    }

    private void select(int i, boolean anim) {
        if (cur.isEmpty()) {
            sel = -1;
            updateHero();
            return;
        }
        i = Math.max(0, Math.min(cur.size() - 1, i));
        if (i == sel) return;
        if (sel >= 0 && sel < tiles.size()) setTileSel(tiles.get(sel), false, anim);
        sel = i;
        setTileSel(tiles.get(i), true, anim);

        int cw = padL * 2 + cur.size() * (tileSize + gap);
        final int target = Math.max(0, Math.min(padL + i * (tileSize + gap) + tileSize / 2 - W / 2, cw - W));
        if (anim) {
            scroller.smoothScrollTo(target, 0);
        } else {
            scroller.post(new Runnable() {
                @Override
                public void run() {
                    scroller.scrollTo(target, 0);
                }
            });
        }
        updateHero();
    }

    private void updateHero() {
        if (sel < 0 || sel >= cur.size()) {
            title.setText("");
            sub.setText("");
            play.setVisibility(View.INVISIBLE);
            bg.setTint(IconCache.DEFAULT_TINT, !lite);
            return;
        }
        Entry e = cur.get(sel);
        title.setText(e.label);
        if (e.type == Entry.ACTION) {
            sub.setText(e.desc);
        } else if (e.last > 0) {
            sub.setText("Последний запуск: " + DateUtils.getRelativeTimeSpanString(
                    e.last, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS));
        } else {
            sub.setText("Ещё не запускалось");
        }
        play.setLabel(tab == TAB_GAMES ? "Играть" : "Открыть");
        play.setVisibility(View.VISIBLE);
        bg.setTint(icons.tint(e.key), !lite);
        if (!lite) {
            title.setAlpha(0f);
            title.animate().alpha(1f).setDuration(160).start();
            sub.setAlpha(0f);
            sub.animate().alpha(1f).setDuration(160).start();
        }
    }

    // ============================================================ запуск
    private void launchSel() {
        if (sel >= 0 && sel < cur.size()) launch(cur.get(sel));
    }

    private void launch(Entry e) {
        if (e.type == Entry.ACTION) {
            runAction(e.key.substring(4));
            return;
        }
        try {
            store.touch(e.key);
            e.last = System.currentTimeMillis();
            startActivity(new Intent(e.intent));
        } catch (Exception ex) {
            Toast.makeText(this, "Не удалось запустить: " + e.label, Toast.LENGTH_SHORT).show();
        }
    }

    private void open(String action) {
        try {
            startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ex) {
            Toast.makeText(this, "Недоступно на этом устройстве", Toast.LENGTH_SHORT).show();
        }
    }

    private void runAction(String id) {
        switch (id) {
            case "m_video":
                openBrowser(MediaUtil.VIDEO);
                break;
            case "m_music":
                openBrowser(MediaUtil.AUDIO);
                break;
            case "m_photo":
                openBrowser(MediaUtil.IMAGE);
                break;
            case "m_files":
                openBrowser(0);
                break;
            case "wifi":
                open(Settings.ACTION_WIFI_SETTINGS);
                break;
            case "bt":
                open(Settings.ACTION_BLUETOOTH_SETTINGS);
                break;
            case "display":
                open(Settings.ACTION_DISPLAY_SETTINGS);
                break;
            case "settings":
                open(Settings.ACTION_SETTINGS);
                break;
            case "home":
                open(Settings.ACTION_HOME_SETTINGS);
                break;
            case "lite":
                lite = !lite;
                store.setLite(lite);
                buildSys();
                showTab(TAB_SYS, "act:lite");
                break;
            default:
                showPanel("PlayHack5 1.1", new String[]{"Закрыть"}, new Runnable[]{new Runnable() {
                    @Override
                    public void run() {
                    }
                }});
        }
    }

    // ============================================================ опции (△ / Y / долгое нажатие)
    private void showOptions() {
        if (sel < 0 || sel >= cur.size()) return;
        final Entry e = cur.get(sel);
        if (e.type != Entry.APP) {
            launch(e);
            return;
        }
        final boolean inGames = e.game;
        showPanel(e.label, new String[]{
                inGames ? "Убрать из «Игры»" : "Добавить в «Игры»", "О приложении", "Удалить", "Закрыть"
        }, new Runnable[]{
                new Runnable() {
                    @Override
                    public void run() {
                        store.setInGames(e.key, !inGames);
                        e.game = !inGames;
                        rebuildLists();
                    }
                },
                new Runnable() {
                    @Override
                    public void run() {
                        try {
                            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", e.key, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        } catch (Exception ignored) {
                        }
                    }
                },
                new Runnable() {
                    @Override
                    public void run() {
                        try {
                            startActivity(new Intent(Intent.ACTION_DELETE,
                                    Uri.fromParts("package", e.key, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        } catch (Exception ignored) {
                        }
                    }
                },
                new Runnable() {
                    @Override
                    public void run() {
                    }
                }
        });
    }

    private static GradientDrawable rr(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(r);
        return g;
    }

    private void showPanel(String head, String[] labels, Runnable[] acts) {
        hidePanel();
        panel = new FrameLayout(this);
        panel.setBackgroundColor(0xCC000814);
        panel.setClickable(true);
        panel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hidePanel();
            }
        });

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rr(0xF0182544, 2 * u));
        int p = (int) (2.5f * u);
        card.setPadding(p, p, p, p);

        TextView h = new TextView(this);
        h.setText(head);
        h.setSingleLine(true);
        h.setEllipsize(TextUtils.TruncateAt.END);
        h.setTextColor(0xB3FFFFFF);
        h.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(3.8f, 12));
        h.setPadding((int) (2 * u), 0, (int) (2 * u), (int) u);
        card.addView(h, new LinearLayout.LayoutParams(-1, -2));

        for (int i = 0; i < labels.length; i++) {
            TextView it = new TextView(this);
            it.setText(labels[i]);
            it.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(4.4f, 14));
            it.setPadding((int) (2 * u), (int) (1.6f * u), (int) (2 * u), (int) (1.6f * u));
            final int ii = i;
            it.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    panelSel = ii;
                    panelPick();
                }
            });
            panelItems.add(it);
            panelActs.add(acts[i]);
            card.addView(it, new LinearLayout.LayoutParams(-1, -2));
        }
        int cw = Math.min((int) (W * 0.8f), (int) Math.max(40 * u, 230 * d));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(cw, -2, Gravity.CENTER);
        panel.addView(card, cp);
        root.addView(panel, new FrameLayout.LayoutParams(-1, -1));
        panelSel = 0;
        paintPanel();
    }

    private void paintPanel() {
        for (int i = 0; i < panelItems.size(); i++) {
            TextView t = panelItems.get(i);
            boolean on = i == panelSel;
            t.setBackground(on ? rr(0xFFFFFFFF, 1.2f * u) : null);
            t.setTextColor(on ? 0xFF0A0F1E : 0xFFFFFFFF);
        }
    }

    private void panelMove(int dir) {
        int n = panelItems.size();
        if (n == 0) return;
        panelSel = (panelSel + dir + n) % n;
        paintPanel();
    }

    private void panelPick() {
        if (panelSel < 0 || panelSel >= panelActs.size()) return;
        Runnable r = panelActs.get(panelSel);
        hidePanel();
        r.run();
    }

    private void hidePanel() {
        if (panel != null) {
            root.removeView(panel);
            panel = null;
        }
        panelItems.clear();
        panelActs.clear();
    }

    // ============================================================ ввод
    private static int map(int k) {
        return Keys.map(k);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent ev) {
        int a = map(ev.getKeyCode());
        if (a == 0) return super.dispatchKeyEvent(ev);
        if (ev.getAction() == KeyEvent.ACTION_DOWN) handle(a, ev.getRepeatCount());
        return true;
    }

    private void handle(int a, int rep) {
        if (panel != null) {
            switch (a) {
                case K_LEFT:
                case K_UP:
                    panelMove(-1);
                    break;
                case K_RIGHT:
                case K_DOWN:
                    panelMove(1);
                    break;
                case K_OK:
                    if (rep == 0) panelPick();
                    break;
                case K_BACK:
                case K_OPTIONS:
                    if (rep == 0) hidePanel();
                    break;
                default:
                    break;
            }
            return;
        }
        switch (a) {
            case K_LEFT:
                select(sel - 1, true);
                break;
            case K_RIGHT:
                select(sel + 1, true);
                break;
            case K_UP:
            case K_PREV:
                if (rep == 0) tabMove(-1);
                break;
            case K_DOWN:
            case K_NEXT:
                if (rep == 0) tabMove(1);
                break;
            case K_OK:
                if (rep == 0) launchSel();
                break;
            case K_OPTIONS:
                if (rep == 0) showOptions();
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        int src = e.getSource();
        if ((src & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                && e.getAction() == MotionEvent.ACTION_MOVE) {
            float x = e.getAxisValue(MotionEvent.AXIS_X);
            float y = e.getAxisValue(MotionEvent.AXIS_Y);
            long now = SystemClock.uptimeMillis();
            if (Math.abs(x) > 0.65f && now - lastAxis > 170) {
                lastAxis = now;
                handle(x > 0 ? K_RIGHT : K_LEFT, 0);
                return true;
            }
            if (Math.abs(y) > 0.75f && now - lastAxis > 300) {
                lastAxis = now;
                handle(y > 0 ? K_DOWN : K_UP, 0);
                return true;
            }
        }
        if ((src & InputDevice.SOURCE_CLASS_POINTER) != 0 && e.getAction() == MotionEvent.ACTION_SCROLL) {
            float v = e.getAxisValue(MotionEvent.AXIS_VSCROLL) - e.getAxisValue(MotionEvent.AXIS_HSCROLL);
            if (v != 0) {
                handle(v < 0 ? K_RIGHT : K_LEFT, 0);
                return true;
            }
        }
        return super.onGenericMotionEvent(e);
    }
}
