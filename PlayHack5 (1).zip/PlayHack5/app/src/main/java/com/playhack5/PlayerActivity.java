package com.playhack5;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.util.VLCVideoLayout;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Проигрыватель видео и аудио на libVLC (почти любые форматы и кодеки, аппаратное декодирование где доступно).
 * ←/→ перемотка, ↑/↓ громкость, ✕/Enter/Space пауза, L1/R1 предыдущий/следующий,
 * △/Menu — звук, субтитры, формат кадра, скорость; ○/Esc — выход. Мышь: клик по шкале, колесо — громкость.
 */
public class PlayerActivity extends Activity {
    private static final MediaPlayer.ScaleType[] SCALES = {
            MediaPlayer.ScaleType.SURFACE_BEST_FIT, MediaPlayer.ScaleType.SURFACE_FIT_SCREEN,
            MediaPlayer.ScaleType.SURFACE_FILL, MediaPlayer.ScaleType.SURFACE_16_9,
            MediaPlayer.ScaleType.SURFACE_4_3, MediaPlayer.ScaleType.SURFACE_ORIGINAL};
    private static final String[] SCALE_NAMES = {"По размеру экрана", "Заполнить (с обрезкой)", "Растянуть",
            "16:9", "4:3", "Оригинальный размер"};
    private static final float[] RATES = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};

    private LibVLC libVLC;
    private MediaPlayer mp;
    private VLCVideoLayout vl;
    private Ui ui;
    private FrameLayout root;
    private Overlay ov;
    private ListPanel panel;
    private AudioManager am;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final long[] axisLast = new long[1];

    private List<String> list;
    private int idx;
    private boolean audio;
    private long resumeAt = -1;
    private long pendingSeek = -1;
    private int scaleIdx = 0;
    private float rate = 1f;
    private long showUntil;
    private String toastText;
    private long toastUntil;
    private long seekPos = -1, seekAt;
    private boolean dragging, moved;
    private float downX, downY;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (ov != null) ov.invalidate();
            h.postDelayed(this, 400);
        }
    };

    private final MediaPlayer.EventListener listener = new MediaPlayer.EventListener() {
        @Override
        public void onEvent(MediaPlayer.Event e) {
            switch (e.type) {
                case MediaPlayer.Event.Playing:
                    onPlaying();
                    break;
                case MediaPlayer.Event.Paused:
                    ov.paused = true;
                    ov.invalidate();
                    break;
                case MediaPlayer.Event.EndReached:
                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            step(1, true);
                        }
                    });
                    break;
                case MediaPlayer.Event.EncounteredError:
                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(PlayerActivity.this, "Не удалось воспроизвести файл", Toast.LENGTH_SHORT).show();
                            step(1, true);
                        }
                    });
                    break;
                default:
                    break;
            }
        }
    };

    // ------------------------------------------------------------------ наложение (шкала, заголовок, аудио-экран)
    private static final class Meta {
        String title, artist, album;
        Bitmap cover;
    }

    private final class Overlay extends View {
        boolean paused;
        String title = "";
        Meta meta;
        int number, total;
        private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final TextPaint tp2 = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final TextPaint tp3 = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final Paint shade = new Paint();
        private final Paint barBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barFg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint coverPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Matrix mx = new Matrix();
        private final RectF rf = new RectF();
        private final Bitmap placeholder;
        private LinearGradient topG, botG;

        Overlay(Context c) {
            super(c);
            tp.setColor(0xFFFFFFFF);
            tp.setTextSize(ui.px(5f, 16));
            tp.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            tp2.setColor(0xB3FFFFFF);
            tp2.setTextSize(ui.px(3.8f, 12));
            tp3.setColor(0xFFFFFFFF);
            tp3.setTextSize(ui.px(3.6f, 12));
            barBg.setColor(0x55FFFFFF);
            barFg.setColor(0xFFFFFFFF);
            pill.setColor(0xB0000000);
            placeholder = Glyphs.make(Glyphs.MUSIC, 256);
            setClickable(false);
        }

        boolean visibleNow() {
            return audio || paused || SystemClock.uptimeMillis() < showUntil;
        }

        @Override
        protected void onSizeChanged(int w, int hh, int ow, int oh) {
            topG = new LinearGradient(0, 0, 0, hh * 0.24f, 0xCC000000, 0, Shader.TileMode.CLAMP);
            botG = new LinearGradient(0, hh * 0.70f, 0, hh, 0, 0xCC000000, Shader.TileMode.CLAMP);
        }

        private String fit(String s, TextPaint p, float w) {
            return TextUtils.ellipsize(s, p, Math.max(10, w), TextUtils.TruncateAt.END).toString();
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), hh = getHeight();
            float u = ui.u;
            float padX = 6 * u;
            long now = SystemClock.uptimeMillis();
            boolean show = visibleNow();

            if (audio) drawAudio(c, w, hh, padX);

            if (show) {
                if (!audio) {
                    shade.setShader(topG);
                    c.drawRect(0, 0, w, hh * 0.24f, shade);
                    c.drawText(fit(title, tp, w - 2 * padX), padX, 5.5f * u + tp.getTextSize() * 0.6f, tp);
                    if (total > 1) {
                        String n = number + "/" + total;
                        c.drawText(n, w - padX - tp2.measureText(n), 5.5f * u + tp2.getTextSize() * 0.6f, tp2);
                    }
                }
                shade.setShader(botG);
                c.drawRect(0, hh * 0.70f, w, hh, shade);

                long len = mp.getLength();
                long t = Math.max(0, mp.getTime());
                float by = hh - 6.5f * u;
                float thick = Math.max(3f, 1.3f * u);
                float l = padX, r = w - padX;
                String ts = MediaUtil.time(t);
                String te = len > 0 ? MediaUtil.time(len) : "--:--";
                float ty = by - 2.6f * u;
                c.drawText(ts, l, ty, tp3);
                c.drawText(te, r - tp3.measureText(te), ty, tp3);
                rf.set(l, by - thick / 2, r, by + thick / 2);
                c.drawRoundRect(rf, thick, thick, barBg);
                float ratio = len > 0 ? Math.min(1f, (float) t / len) : 0f;
                rf.set(l, by - thick / 2, l + (r - l) * ratio, by + thick / 2);
                c.drawRoundRect(rf, thick, thick, barFg);
                c.drawCircle(l + (r - l) * ratio, by, thick * 1.5f, barFg);
            }

            if (paused && !audio) {
                float s = 6 * u;
                rf.set(w / 2f - s * 0.9f, hh / 2f - s, w / 2f - s * 0.25f, hh / 2f + s);
                c.drawRoundRect(rf, s * 0.15f, s * 0.15f, barFg);
                rf.set(w / 2f + s * 0.25f, hh / 2f - s, w / 2f + s * 0.9f, hh / 2f + s);
                c.drawRoundRect(rf, s * 0.15f, s * 0.15f, barFg);
            }

            if (toastText != null && now < toastUntil) {
                float tw = tp3.measureText(toastText);
                float ph = tp3.getTextSize() * 2.2f;
                float cy = hh * 0.17f;
                rf.set((w - tw) / 2f - ph * 0.6f, cy - ph / 2, (w + tw) / 2f + ph * 0.6f, cy + ph / 2);
                c.drawRoundRect(rf, ph / 2, ph / 2, pill);
                c.drawText(toastText, (w - tw) / 2f, cy + tp3.getTextSize() * 0.35f, tp3);
            }
        }

        private void drawAudio(Canvas c, int w, int hh, float padX) {
            float u = ui.u;
            int side = (int) Math.min(hh * 0.56f, w * 0.34f);
            float left = padX * 1.3f;
            float top = (hh - side) / 2f - 4 * u;
            Bitmap cov = (meta != null && meta.cover != null) ? meta.cover : placeholder;
            BitmapShader sh = new BitmapShader(cov, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            mx.setScale((float) side / cov.getWidth(), (float) side / cov.getHeight());
            mx.postTranslate(left, top);
            sh.setLocalMatrix(mx);
            coverPaint.setShader(sh);
            rf.set(left, top, left + side, top + side);
            c.drawRoundRect(rf, side * 0.06f, side * 0.06f, coverPaint);

            float x = left + side + 4 * u;
            float avail = w - x - padX;
            String l1 = (meta != null && meta.title != null && !meta.title.isEmpty()) ? meta.title : title;
            StringBuilder sb = new StringBuilder();
            if (meta != null && meta.artist != null) sb.append(meta.artist);
            if (meta != null && meta.album != null) {
                if (sb.length() > 0) sb.append(" — ");
                sb.append(meta.album);
            }
            float y = top + side * 0.38f;
            c.drawText(fit(l1, tp, avail), x, y, tp);
            if (sb.length() > 0) c.drawText(fit(sb.toString(), tp2, avail), x, y + tp.getTextSize() * 1.1f, tp2);
            if (total > 1) c.drawText(number + " / " + total, x, y + tp.getTextSize() * 2.1f, tp2);
        }
    }

    // ------------------------------------------------------------------ жизненный цикл
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ui = new Ui(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);

        list = MediaUtil.playlist;
        idx = getIntent().getIntExtra("index", 0);
        audio = getIntent().getIntExtra("kind", MediaUtil.VIDEO) == MediaUtil.AUDIO;
        if (list == null || list.isEmpty() || idx < 0 || idx >= list.size()) {
            finish();
            return;
        }

        libVLC = new LibVLC(this);
        mp = new MediaPlayer(libVLC);
        mp.setEventListener(listener);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        if (!audio) {
            vl = new VLCVideoLayout(this);
            root.addView(vl, new FrameLayout.LayoutParams(-1, -1));
        }
        ov = new Overlay(this);
        root.addView(ov, new FrameLayout.LayoutParams(-1, -1));
        panel = new ListPanel(root, ui);
        setContentView(root);
        h.post(tick);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mp == null) return;
        if (!audio) mp.attachViews(vl, null, true, false);
        playCurrent(resumeAt);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mp == null) return;
        try {
            long t = mp.getTime();
            if (t > 0) resumeAt = t;
        } catch (Exception ignored) {
        }
        mp.stop();
        if (!audio) mp.detachViews();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
        io.shutdownNow();
        if (mp != null) {
            mp.setEventListener(null);
            mp.release();
        }
        if (libVLC != null) libVLC.release();
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) Ui.immersive(this);
    }

    // ------------------------------------------------------------------ воспроизведение
    private void playCurrent(long seekTo) {
        String p = list.get(idx);
        Media m = new Media(libVLC, Uri.fromFile(new File(p)));
        m.setHWDecoderEnabled(true, false);
        mp.setMedia(m);
        m.release();
        pendingSeek = seekTo;
        ov.title = new File(p).getName();
        ov.number = idx + 1;
        ov.total = list.size();
        ov.meta = null;
        ov.paused = false;
        mp.play();
        showUntil = SystemClock.uptimeMillis() + 4000;
        if (audio) loadMeta(p, idx);
    }

    private void onPlaying() {
        ov.paused = false;
        if (pendingSeek > 0) {
            mp.setTime(pendingSeek);
            pendingSeek = -1;
        }
        if (rate != 1f) mp.setRate(rate);
        if (!audio) mp.setVideoScale(SCALES[scaleIdx]);
        ov.invalidate();
    }

    private void step(int dir, boolean fromEnd) {
        int n = idx + dir;
        if (n < 0 || n >= list.size()) {
            if (fromEnd) finish();
            return;
        }
        idx = n;
        resumeAt = -1;
        playCurrent(-1);
    }

    private void togglePause() {
        if (mp.isPlaying()) {
            mp.pause();
            ov.paused = true;
        } else {
            mp.play();
            ov.paused = false;
        }
        show();
    }

    private void show() {
        showUntil = SystemClock.uptimeMillis() + 3500;
        ov.invalidate();
    }

    private void toast(String s) {
        toastText = s;
        toastUntil = SystemClock.uptimeMillis() + 1300;
        ov.invalidate();
    }

    private void seekBy(long delta) {
        long now = SystemClock.uptimeMillis();
        long base = (now - seekAt < 800 && seekPos >= 0) ? seekPos : mp.getTime();
        long len = mp.getLength();
        long t = Math.max(0, base + delta);
        if (len > 0 && t > len - 500) t = Math.max(0, len - 500);
        mp.setTime(t);
        seekPos = t;
        seekAt = now;
        toast((delta > 0 ? "+" : "−") + Math.abs(delta / 1000) + " с   " + MediaUtil.time(t));
        show();
    }

    private void volume(int dir) {
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                dir > 0 ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, 0);
        int v = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        toast("Громкость " + v + "/" + max);
        show();
    }

    private void seekToX(float x) {
        long len = mp.getLength();
        if (len <= 0) return;
        float l = 6 * ui.u, r = ui.W - 6 * ui.u;
        float ratio = Math.max(0f, Math.min(1f, (x - l) / (r - l)));
        long t = (long) (ratio * len);
        mp.setTime(t);
        seekPos = t;
        seekAt = SystemClock.uptimeMillis();
        show();
    }

    // ------------------------------------------------------------------ меню (звук, субтитры, формат, скорость)
    private void openMenu() {
        final List<String> labels = new ArrayList<>();
        final List<String> codes = new ArrayList<>();
        if (!audio) {
            labels.add("Звуковая дорожка");
            codes.add("audio");
            labels.add("Субтитры");
            codes.add("subs");
            labels.add("Формат кадра: " + SCALE_NAMES[scaleIdx]);
            codes.add("scale");
        }
        labels.add("Скорость: " + rate + "×");
        codes.add("rate");
        labels.add("Закрыть меню");
        codes.add("close");
        panel.show(audio ? "Аудио" : "Видео", labels, 0, new ListPanel.Pick() {
            @Override
            public void on(int i) {
                String code = codes.get(i);
                if (code.equals("audio")) pickTrack(false);
                else if (code.equals("subs")) pickTrack(true);
                else if (code.equals("scale")) pickScale();
                else if (code.equals("rate")) pickRate();
            }
        });
    }

    private void pickTrack(final boolean subs) {
        final MediaPlayer.TrackDescription[] t = subs ? mp.getSpuTracks() : mp.getAudioTracks();
        if (t == null || t.length == 0) {
            toast(subs ? "Субтитров нет" : "Дорожек нет");
            return;
        }
        int cur = subs ? mp.getSpuTrack() : mp.getAudioTrack();
        List<String> names = new ArrayList<>();
        int selIdx = 0;
        for (int i = 0; i < t.length; i++) {
            names.add(t[i].name);
            if (t[i].id == cur) selIdx = i;
        }
        panel.show(subs ? "Субтитры" : "Звуковая дорожка", names, selIdx, new ListPanel.Pick() {
            @Override
            public void on(int i) {
                if (subs) mp.setSpuTrack(t[i].id);
                else mp.setAudioTrack(t[i].id);
                toast(t[i].name);
            }
        });
    }

    private void pickScale() {
        List<String> names = new ArrayList<>();
        for (String s : SCALE_NAMES) names.add(s);
        panel.show("Формат кадра", names, scaleIdx, new ListPanel.Pick() {
            @Override
            public void on(int i) {
                scaleIdx = i;
                mp.setVideoScale(SCALES[i]);
                toast(SCALE_NAMES[i]);
            }
        });
    }

    private void pickRate() {
        List<String> names = new ArrayList<>();
        int sel = 2;
        for (int i = 0; i < RATES.length; i++) {
            names.add(RATES[i] + "×");
            if (RATES[i] == rate) sel = i;
        }
        panel.show("Скорость", names, sel, new ListPanel.Pick() {
            @Override
            public void on(int i) {
                rate = RATES[i];
                mp.setRate(rate);
                toast("Скорость " + rate + "×");
            }
        });
    }

    // ------------------------------------------------------------------ обложка и теги для музыки
    private void loadMeta(final String path, final int forIdx) {
        io.execute(new Runnable() {
            @Override
            public void run() {
                final Meta m = new Meta();
                MediaMetadataRetriever r = new MediaMetadataRetriever();
                try {
                    r.setDataSource(path);
                    m.title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                    m.artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                    m.album = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                    byte[] pic = r.getEmbeddedPicture();
                    if (pic != null) m.cover = decode(pic);
                } catch (Exception ignored) {
                } finally {
                    try {
                        r.release();
                    } catch (Exception ignored) {
                    }
                }
                if (m.cover == null) m.cover = folderCover(path);
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        if (forIdx == idx && !isFinishing()) {
                            ov.meta = m;
                            ov.invalidate();
                        }
                    }
                });
            }
        });
    }

    private static Bitmap decode(byte[] data) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, o);
        int s = 1;
        while (o.outWidth / s > 600) s *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = s;
        return BitmapFactory.decodeByteArray(data, 0, data.length, o);
    }

    private static Bitmap folderCover(String path) {
        File d = new File(path).getParentFile();
        if (d == null) return null;
        String[] names = {"cover.jpg", "folder.jpg", "front.jpg", "albumart.jpg", "cover.png", "folder.png"};
        for (String n : names) {
            File f = new File(d, n);
            if (f.isFile()) {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                int s = 1;
                while (o.outWidth / s > 600) s *= 2;
                o.inJustDecodeBounds = false;
                o.inSampleSize = s;
                Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                if (b != null) return b;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ ввод
    private void handle(int a, int rep) {
        if (panel.showing()) {
            switch (a) {
                case Keys.UP:
                case Keys.LEFT:
                    panel.move(-1);
                    break;
                case Keys.DOWN:
                case Keys.RIGHT:
                    panel.move(1);
                    break;
                case Keys.OK:
                    if (rep == 0) panel.fire();
                    break;
                case Keys.BACK:
                case Keys.OPTIONS:
                    if (rep == 0) panel.hide();
                    break;
                default:
                    break;
            }
            return;
        }
        switch (a) {
            case Keys.OK:
                if (rep == 0) togglePause();
                break;
            case Keys.LEFT:
                if (rep == 0) seekBy(-10000);
                else if (rep % 6 == 0) seekBy(-30000);
                break;
            case Keys.RIGHT:
                if (rep == 0) seekBy(10000);
                else if (rep % 6 == 0) seekBy(30000);
                break;
            case Keys.UP:
                if (rep % 2 == 0) volume(1);
                break;
            case Keys.DOWN:
                if (rep % 2 == 0) volume(-1);
                break;
            case Keys.PREV:
                if (rep == 0) step(-1, false);
                break;
            case Keys.NEXT:
                if (rep == 0) step(1, false);
                break;
            case Keys.OPTIONS:
                if (rep == 0) openMenu();
                break;
            case Keys.BACK:
                if (rep == 0) finish();
                break;
            default:
                break;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent ev) {
        int a = Keys.map(ev.getKeyCode());
        if (a == 0) return super.dispatchKeyEvent(ev);
        if (ev.getAction() == KeyEvent.ACTION_DOWN) handle(a, ev.getRepeatCount());
        return true;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        if (panel == null || panel.showing()) return super.dispatchTouchEvent(e);
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                moved = false;
                dragging = ov.visibleNow() && y > ui.H - 16 * ui.u && mp.getLength() > 0;
                if (dragging) seekToX(x);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging) seekToX(x);
                else if (Math.hypot(x - downX, y - downY) > 12) moved = true;
                return true;
            case MotionEvent.ACTION_UP:
                if (dragging) dragging = false;
                else if (!moved) {
                    if (audio || ov.visibleNow()) togglePause();
                    else show();
                }
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        if (panel.showing()) return super.onGenericMotionEvent(e);
        int act = e.getAction();
        if (act == MotionEvent.ACTION_HOVER_MOVE) {
            show();
            return true;
        }
        if (act == MotionEvent.ACTION_SCROLL) {
            float v = e.getAxisValue(MotionEvent.AXIS_VSCROLL);
            if (v != 0) {
                volume(v > 0 ? 1 : -1);
                return true;
            }
        }
        int a = Keys.stick(e, axisLast);
        if (a != 0) {
            handle(a, 0);
            return true;
        }
        return super.onGenericMotionEvent(e);
    }
}
