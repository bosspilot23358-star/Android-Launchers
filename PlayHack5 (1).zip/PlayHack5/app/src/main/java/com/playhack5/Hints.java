package com.playhack5;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/**
 * Строка подсказок внизу экрана в стиле консоли.
 * Элемент: {"x","Играть"} (✕), {"t",..} (△), {"o",..} (○), {"s",..} (□), {"b","L1,R1","Вкладки"} (плашки).
 */
final class Hints extends View {
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sym = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int left;
    private final String[][] items;
    private final Path tri = new Path();
    private final RectF rf = new RectF();

    Hints(Context c, float textPx, int left, String[][] items) {
        super(c);
        this.left = left;
        this.items = items;
        text.setTextSize(textPx);
        text.setColor(0xCCFFFFFF);
        sym.setStyle(Paint.Style.STROKE);
        sym.setStrokeWidth(Math.max(2f, textPx * 0.14f));
        sym.setStrokeCap(Paint.Cap.ROUND);
        sym.setStrokeJoin(Paint.Join.ROUND);
        badge.setStyle(Paint.Style.STROKE);
        badge.setStrokeWidth(Math.max(1.5f, textPx * 0.08f));
        badge.setColor(0x99FFFFFF);
    }

    private float label(Canvas c, String s, float x, float cy) {
        c.drawText(s, x, cy + text.getTextSize() * 0.35f, text);
        return x + text.measureText(s);
    }

    private float badge(Canvas c, String s, float x, float cy) {
        float pad = text.getTextSize() * 0.35f;
        float w = text.measureText(s) + pad * 2;
        float h = text.getTextSize() * 1.25f;
        rf.set(x, cy - h / 2, x + w, cy + h / 2);
        c.drawRoundRect(rf, h / 2, h / 2, badge);
        c.drawText(s, x + pad, cy + text.getTextSize() * 0.35f, text);
        return x + w;
    }

    @Override
    protected void onDraw(Canvas c) {
        float cy = getHeight() / 2f;
        float s = text.getTextSize() * 0.5f;
        float x = left;
        float gap = text.getTextSize() * 2.0f;
        for (String[] it : items) {
            String code = it[0];
            if (code.equals("b")) {
                String[] bs = it[1].split(",");
                for (int i = 0; i < bs.length; i++) {
                    x = badge(c, bs[i], x, cy) + (i < bs.length - 1 ? s * 0.5f : s * 0.8f);
                }
                x = label(c, it[2], x, cy) + gap;
                continue;
            }
            float xc = x + s;
            switch (code) {
                case "x":
                    sym.setColor(0xFF7AB2FF);
                    c.drawLine(xc - s * 0.6f, cy - s * 0.6f, xc + s * 0.6f, cy + s * 0.6f, sym);
                    c.drawLine(xc - s * 0.6f, cy + s * 0.6f, xc + s * 0.6f, cy - s * 0.6f, sym);
                    break;
                case "t":
                    sym.setColor(0xFF5BD6A5);
                    tri.reset();
                    tri.moveTo(xc, cy - s * 0.75f);
                    tri.lineTo(xc + s * 0.75f, cy + s * 0.55f);
                    tri.lineTo(xc - s * 0.75f, cy + s * 0.55f);
                    tri.close();
                    c.drawPath(tri, sym);
                    break;
                case "o":
                    sym.setColor(0xFFFF8A9A);
                    c.drawCircle(xc, cy, s * 0.72f, sym);
                    break;
                default: // "s"
                    sym.setColor(0xFFE79BFF);
                    rf.set(xc - s * 0.65f, cy - s * 0.65f, xc + s * 0.65f, cy + s * 0.65f);
                    c.drawRect(rf, sym);
                    break;
            }
            x = label(c, it[1], xc + s * 1.5f, cy) + gap;
        }
    }
}
