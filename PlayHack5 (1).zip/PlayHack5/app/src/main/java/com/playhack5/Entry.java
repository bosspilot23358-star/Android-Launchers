package com.playhack5;

import android.content.Intent;

/** Элемент ряда: установленное приложение/игра или пункт настроек. */
final class Entry {
    static final int APP = 0;
    static final int ACTION = 1;

    final int type;
    String key;          // имя пакета или "act:<id>"
    String label;
    String desc = "";
    Intent intent;       // для APP
    long last;           // время последнего запуска
    boolean game;        // показывать во вкладке «Игры»
    int glyph;           // для ACTION

    Entry(int type) {
        this.type = type;
    }
}
