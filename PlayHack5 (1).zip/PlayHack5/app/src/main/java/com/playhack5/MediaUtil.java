package com.playhack5;

import android.os.Environment;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

/** Типы файлов, форматирование, список хранилищ. */
final class MediaUtil {
    static final int OTHER = 0, VIDEO = 1, AUDIO = 2, IMAGE = 3;

    /** Текущий плейлист (в пределах процесса): пути файлов одного типа из открытой папки. */
    static ArrayList<String> playlist = new ArrayList<>();

    private static final HashSet<String> VIDEO_EXT = set(
            "mp4 mkv avi mov wmv flv webm mpg mpeg mpe m4v ts m2ts mts 3gp 3g2 ogv ogm vob divx rmvb rm asf f4v mxf m2v mpv dv wtv");
    private static final HashSet<String> AUDIO_EXT = set(
            "mp3 flac wav ogg oga opus m4a aac wma ape alac aiff aif aifc mka ac3 eac3 dts wv mpc amr mp2 mp1 tta caf weba spx");
    private static final HashSet<String> IMAGE_EXT = set(
            "jpg jpeg jpe png webp bmp gif heic heif avif wbmp");

    private MediaUtil() {
    }

    private static HashSet<String> set(String s) {
        return new HashSet<>(Arrays.asList(s.split(" ")));
    }

    static int kind(String name) {
        int i = name.lastIndexOf('.');
        if (i < 0 || i == name.length() - 1) return OTHER;
        String e = name.substring(i + 1).toLowerCase(Locale.ROOT);
        if (VIDEO_EXT.contains(e)) return VIDEO;
        if (AUDIO_EXT.contains(e)) return AUDIO;
        if (IMAGE_EXT.contains(e)) return IMAGE;
        return OTHER;
    }

    static String size(long b) {
        if (b < 1024) return b + " Б";
        String[] u = {"КБ", "МБ", "ГБ", "ТБ"};
        double v = b;
        int i = -1;
        do {
            v /= 1024;
            i++;
        } while (v >= 1024 && i < 3);
        return String.format(Locale.US, v >= 100 ? "%.0f %s" : "%.1f %s", v, u[i]);
    }

    static String time(long ms) {
        if (ms < 0) ms = 0;
        long s = ms / 1000;
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d", h, m, sec);
        return String.format(Locale.US, "%d:%02d", m, sec);
    }

    /** «Естественная» сортировка: file2 < file10. */
    static int natural(String a, String b) {
        int i = 0, j = 0, la = a.length(), lb = b.length();
        while (i < la && j < lb) {
            char x = a.charAt(i), y = b.charAt(j);
            if (Character.isDigit(x) && Character.isDigit(y)) {
                int si = i, sj = j;
                while (i < la && Character.isDigit(a.charAt(i))) i++;
                while (j < lb && Character.isDigit(b.charAt(j))) j++;
                String na = a.substring(si, i).replaceFirst("^0+", "");
                String nb = b.substring(sj, j).replaceFirst("^0+", "");
                if (na.length() != nb.length()) return na.length() < nb.length() ? -1 : 1;
                int c = na.compareTo(nb);
                if (c != 0) return c;
            } else {
                int c = Character.compare(Character.toLowerCase(x), Character.toLowerCase(y));
                if (c != 0) return c;
                i++;
                j++;
            }
        }
        return Integer.compare(la - i, lb - j);
    }

    static final class Root {
        final String label;
        final File dir;

        Root(String label, File dir) {
            this.label = label;
            this.dir = dir;
        }
    }

    /** Внутренняя память, флешки/SD из /storage и быстрые папки (Movies, Music…). */
    static List<Root> roots(int mode) {
        List<Root> r = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        File internal = Environment.getExternalStorageDirectory();
        if (internal != null && internal.exists()) {
            r.add(new Root("Внутренняя память", internal));
            seen.add(internal.getAbsolutePath());
        }
        File[] vols = new File("/storage").listFiles();
        if (vols != null) {
            for (File f : vols) {
                String n = f.getName();
                if (n.equals("self") || n.equals("emulated")) continue;
                if (!f.isDirectory() || !f.canRead()) continue;
                if (seen.add(f.getAbsolutePath())) r.add(new Root("USB / SD: " + n, f));
            }
        }
        if (internal != null) {
            String[] names;
            switch (mode) {
                case VIDEO:
                    names = new String[]{"Movies", "DCIM", "Download"};
                    break;
                case AUDIO:
                    names = new String[]{"Music", "Download"};
                    break;
                case IMAGE:
                    names = new String[]{"Pictures", "DCIM", "Download"};
                    break;
                default:
                    names = new String[]{"Movies", "Music", "Pictures", "Download"};
                    break;
            }
            for (String n : names) {
                File f = new File(internal, n);
                if (f.isDirectory() && seen.add(f.getAbsolutePath())) r.add(new Root(n, f));
            }
        }
        return r;
    }
}
