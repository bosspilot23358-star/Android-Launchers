package com.playhack5;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Обзор файлов: видео / музыка / фото / все файлы.
 * Клавиши: ↑↓ — выбор, ←→ или L1/R1 — страница, ✕/Enter — открыть, ○/Esc/ПКМ — назад.
 */
public class BrowserActivity extends Activity {
    private static final int T_FOLDER = 0, T_FILE = 1, T_ROOT = 2, T_MSG = 3, T_PERM = 4;
    private static final int[] TINTS = {0xFF0B2A5B, 0xFF6B1E2A, 0xFF5B1F5F, 0xFF1F5B4A};
    private static final String[] TITLES = {"Файлы", "Видео", "Музыка", "Фото"};

    private static final class Item {
        int type;
        int kind;
        String name;
        String meta = "";
        File file;
        int glyph;
        boolean dim;
    }

    private Ui ui;
    private int mode;
    private FrameLayout root;
    private Views.BackgroundView bg;
    private TextView pathV, count;
    private ListView list;
    private int rowH, iconSize;
    private final Paint[] iconPaints = new Paint[Glyphs.COUNT];
    private List<Item> items = new ArrayList<>();
    private int selPos;
    private File dir;
    private boolean hadAccess;
    private List<MediaUtil.Root> roots = new ArrayList<>();
    private final HashMap<String, Integer> posMem = new HashMap<>();
    private final long[] axisLast = new long[1];
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler h = new Handler(Looper.getMainLooper());

    // ------------------------------------------------------------------ строка списка
    private final class RowView extends View {
        Item it;
        boolean sel;
        private final Paint name = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint meta = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();

        RowView(Context c) {
            super(c);
            name.setTextSize(ui.px(4.6f, 15));
            name.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            meta.setTextSize(ui.px(3.6f, 12));
            meta.setColor(0x99FFFFFF);
            fill.setColor(0x33FFFFFF);
            ring.setStyle(Paint.Style.STROKE);
            ring.setColor(0xFFFFFFFF);
            ring.setStrokeWidth(Math.max(1.5f, ui.u * 0.5f));
        }

        @Override
        protected void onMeasure(int w, int hh) {
            setMeasuredDimension(MeasureSpec.getSize(w), rowH);
        }

        @Override
        protected void onDraw(Canvas c) {
            if (it == null) return;
            int w = getWidth(), hh = getHeight();
            float r = hh * 0.25f;
            if (sel) {
                rf.set(0, 0, w, hh);
                c.drawRoundRect(rf, r, r, fill);
                float in = ring.getStrokeWidth() / 2;
                rf.set(in, in, w - in, hh - in);
                c.drawRoundRect(rf, r, r, ring);
            }
            float ix = hh * 0.2f;
            float iy = (hh - iconSize) / 2f;
            c.save();
            c.translate(ix, iy);
            Paint ip = iconPaint(it.glyph);
            ip.setAlpha(it.dim ? 110 : 255);
            c.drawRoundRect(0, 0, iconSize, iconSize, iconSize * 0.18f, iconSize * 0.18f, ip);
            c.restore();

            float rightPad = hh * 0.35f;
            float metaW = it.meta.isEmpty() ? 0 : meta.measureText(it.meta);
            float nx = ix + iconSize + hh * 0.3f;
            float avail = w - rightPad - metaW - nx - (metaW > 0 ? hh * 0.3f : 0);
            name.setColor(it.dim ? 0x88FFFFFF : 0xFFFFFFFF);
            String t = TextUtils.ellipsize(it.name, new android.text.TextPaint(name), Math.max(10, avail),
                    TextUtils.TruncateAt.END).toString();
            c.drawText(t, nx, hh / 2f + name.getTextSize() * 0.35f, name);
            if (metaW > 0) c.drawText(it.meta, w - rightPad - metaW, hh / 2f + meta.getTextSize() * 0.35f, meta);
        }
    }

    private Paint iconPaint(int g) {
        if (iconPaints[g] == null) {
            Bitmap b = Glyphs.make(g, iconSize);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            p.setShader(new BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            iconPaints[g] = p;
        }
        return iconPaints[g];
    }

    private final BaseAdapter adapter = new BaseAdapter() {
        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int p) {
            return items.get(p);
        }

        @Override
        public long getItemId(int p) {
            return p;
        }

        @Override
        public View getView(int p, View cv, ViewGroup parent) {
            RowView r;
            if (cv instanceof RowView) {
                r = (RowView) cv;
            } else {
                r = new RowView(BrowserActivity.this);
                r.setLayoutParams(new AbsListView.LayoutParams(-1, rowH));
            }
            r.it = items.get(p);
            r.sel = p == selPos;
            r.invalidate();
            return r;
        }
    };

    // ------------------------------------------------------------------ жизненный цикл
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ui = new Ui(this);
        mode = getIntent().getIntExtra("mode", 0);
        if (mode < 0 || mode > 3) mode = 0;
        rowH = (int) ui.px(10f, 40);
        iconSize = (int) (rowH * 0.72f);
        int padL = (int) (6 * ui.u);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF02050C);
        bg = new Views.BackgroundView(this);
        bg.setTint(TINTS[mode], false);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        TextView title = new TextView(this);
        title.setText(TITLES[mode]);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, ui.px(6.4f, 20));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2);
        tp.leftMargin = padL;
        tp.topMargin = (int) (2.5f * ui.u);
        root.addView(title, tp);

        count = new TextView(this);
        count.setTextColor(0x99FFFFFF);
        count.setTextSize(TypedValue.COMPLEX_UNIT_PX, ui.px(3.6f, 12));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        cp.rightMargin = padL;
        cp.topMargin = (int) (4.5f * ui.u);
        root.addView(count, cp);

        pathV = new TextView(this);
        pathV.setTextColor(0xB3FFFFFF);
        pathV.setSingleLine(true);
        pathV.setEllipsize(TextUtils.TruncateAt.START);
        pathV.setTextSize(TypedValue.COMPLEX_UNIT_PX, ui.px(3.6f, 11));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(ui.W - 2 * padL, -2);
        pp.leftMargin = padL;
        pp.topMargin = (int) (12 * ui.u);
        root.addView(pathV, pp);

        list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new ColorDrawable(0));
        list.setCacheColorHint(0);
        list.setVerticalScrollBarEnabled(false);
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        list.setFocusable(false);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int pos, long id) {
                selPos = pos;
                adapter.notifyDataSetChanged();
                openSel();
            }
        });
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ui.W - padL, (int) (70 * ui.u));
        lp.leftMargin = padL / 2;
        lp.topMargin = (int) (17.5f * ui.u);
        root.addView(list, lp);

        Hints hints = new Hints(this, ui.px(3.8f, 10), padL, new String[][]{
                {"x", "Открыть"}, {"o", "Назад"}, {"b", "L1,R1", "Страница"}});
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(ui.W, (int) (8 * ui.u));
        hp.topMargin = (int) (90 * ui.u);
        root.addView(hints, hp);

        setContentView(root);
        hadAccess = hasAccess();
        showRoots();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean now = hasAccess();
        if (now != hadAccess) {
            hadAccess = now;
            if (dir == null) showRoots();
            else showDir(dir, 0);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdown();
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) Ui.immersive(this);
    }

    @Override
    public void onBackPressed() {
        up();
    }

    // ------------------------------------------------------------------ доступ к файлам
    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        if (Build.VERSION.SDK_INT >= 23) {
            return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
                return;
            } catch (Exception ignored) {
            }
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                return;
            } catch (Exception ignored) {
            }
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
                return;
            } catch (Exception ignored) {
            }
            Toast.makeText(this, "Выдайте доступ командой: adb shell appops set " + getPackageName()
                    + " MANAGE_EXTERNAL_STORAGE allow", Toast.LENGTH_LONG).show();
        } else if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        hadAccess = hasAccess();
        showRoots();
    }

    // ------------------------------------------------------------------ навигация
    private Item msg(String text) {
        Item m = new Item();
        m.type = T_MSG;
        m.name = text;
        m.glyph = Glyphs.INFO;
        m.dim = true;
        return m;
    }

    private void setItems(List<Item> l, int sel, boolean center) {
        items = l;
        selPos = Math.max(0, Math.min(sel, items.size() - 1));
        adapter.notifyDataSetChanged();
        if (center) {
            list.setSelectionFromTop(selPos, Math.max(0, list.getHeight() / 2 - rowH / 2));
        } else {
            list.setSelection(0);
        }
        boolean real = dir != null && !(items.size() == 1 && items.get(0).type == T_MSG);
        count.setText(real ? "Всего: " + items.size() : "");
    }

    private void showRoots() {
        dir = null;
        roots = MediaUtil.roots(mode);
        pathV.setText("Выберите хранилище");
        List<Item> l = new ArrayList<>();
        if (!hasAccess()) {
            Item p = new Item();
            p.type = T_PERM;
            p.name = "Разрешить доступ к файлам";
            p.meta = "нажмите OK";
            p.glyph = Glyphs.GEAR;
            l.add(p);
        }
        for (MediaUtil.Root r : roots) {
            Item it = new Item();
            it.type = T_ROOT;
            it.name = r.label;
            it.file = r.dir;
            it.glyph = r.label.startsWith("USB") || r.label.startsWith("Внутр") ? Glyphs.STORAGE : Glyphs.FOLDER;
            try {
                StatFs sf = new StatFs(r.dir.getAbsolutePath());
                if (it.glyph == Glyphs.STORAGE) it.meta = MediaUtil.size(sf.getAvailableBytes()) + " свободно";
            } catch (Exception ignored) {
            }
            l.add(it);
        }
        if (roots.isEmpty()) l.add(msg("Хранилища не найдены"));
        setItems(l, 0, false);
        count.setText("");
    }

    private boolean isRoot(File f) {
        for (MediaUtil.Root r : roots) {
            if (r.dir.getAbsolutePath().equals(f.getAbsolutePath())) return true;
        }
        return false;
    }

    private void showDir(final File d, final int restore) {
        dir = d;
        pathV.setText(d.getAbsolutePath());
        io.execute(new Runnable() {
            @Override
            public void run() {
                final List<Item> l = listDir(d);
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || dir == null || !dir.equals(d)) return;
                        setItems(l, restore, restore > 0);
                    }
                });
            }
        });
    }

    private List<Item> listDir(File d) {
        List<Item> out = new ArrayList<>();
        File[] fs = d.listFiles();
        if (fs == null) {
            out.add(msg(hasAccess() ? "Нет доступа к папке" : "Нет доступа к файлам"));
            return out;
        }
        List<Item> dirs = new ArrayList<>();
        List<Item> files = new ArrayList<>();
        for (File f : fs) {
            String n = f.getName();
            if (n.startsWith(".")) continue;
            Item it = new Item();
            it.name = n;
            it.file = f;
            if (f.isDirectory()) {
                it.type = T_FOLDER;
                it.glyph = Glyphs.FOLDER;
                dirs.add(it);
            } else {
                int k = MediaUtil.kind(n);
                if (mode != 0 && k != mode) continue;
                it.type = T_FILE;
                it.kind = k;
                it.meta = MediaUtil.size(f.length());
                it.dim = k == MediaUtil.OTHER;
                it.glyph = k == MediaUtil.VIDEO ? Glyphs.VIDEO : k == MediaUtil.AUDIO ? Glyphs.MUSIC
                        : k == MediaUtil.IMAGE ? Glyphs.PHOTO : Glyphs.FILE;
                files.add(it);
            }
        }
        Comparator<Item> cmp = new Comparator<Item>() {
            @Override
            public int compare(Item a, Item b) {
                return MediaUtil.natural(a.name, b.name);
            }
        };
        Collections.sort(dirs, cmp);
        Collections.sort(files, cmp);
        out.addAll(dirs);
        out.addAll(files);
        if (out.isEmpty()) out.add(msg("Здесь нет подходящих файлов"));
        return out;
    }

    private void up() {
        if (dir == null) {
            finish();
            return;
        }
        if (isRoot(dir)) {
            showRoots();
            return;
        }
        File p = dir.getParentFile();
        if (p == null) {
            showRoots();
            return;
        }
        Integer pos = posMem.get(p.getAbsolutePath());
        showDir(p, pos == null ? 0 : pos);
    }

    private void openSel() {
        if (selPos < 0 || selPos >= items.size()) return;
        Item it = items.get(selPos);
        switch (it.type) {
            case T_PERM:
                requestAccess();
                break;
            case T_ROOT:
            case T_FOLDER:
                if (dir != null) posMem.put(dir.getAbsolutePath(), selPos);
                showDir(it.file, 0);
                break;
            case T_FILE:
                openFile(it);
                break;
            default:
                break;
        }
    }

    private void openFile(Item it) {
        if (it.kind == MediaUtil.OTHER) {
            Toast.makeText(this, "Этот формат не поддерживается", Toast.LENGTH_SHORT).show();
            return;
        }
        ArrayList<String> pl = new ArrayList<>();
        int at = 0;
        for (Item o : items) {
            if (o.type == T_FILE && o.kind == it.kind) {
                if (o == it) at = pl.size();
                pl.add(o.file.getAbsolutePath());
            }
        }
        MediaUtil.playlist = pl;
        Intent i = new Intent(this, it.kind == MediaUtil.IMAGE ? ImageActivity.class : PlayerActivity.class);
        i.putExtra("index", at).putExtra("kind", it.kind);
        startActivity(i);
    }

    // ------------------------------------------------------------------ выбор строки
    private void ensureVisible() {
        int first = list.getFirstVisiblePosition(), last = list.getLastVisiblePosition();
        if (selPos <= first) list.setSelectionFromTop(selPos, 0);
        else if (selPos >= last) list.setSelectionFromTop(selPos, Math.max(0, list.getHeight() - rowH));
    }

    private void move(int delta) {
        if (items.isEmpty()) return;
        int n = Math.max(0, Math.min(items.size() - 1, selPos + delta));
        if (n == selPos) return;
        selPos = n;
        adapter.notifyDataSetChanged();
        ensureVisible();
    }

    private int page() {
        return Math.max(1, list.getHeight() / rowH - 1);
    }

    // ------------------------------------------------------------------ ввод
    private void handle(int a, int rep) {
        switch (a) {
            case Keys.UP:
                move(-1);
                break;
            case Keys.DOWN:
                move(1);
                break;
            case Keys.LEFT:
            case Keys.PREV:
                move(-page());
                break;
            case Keys.RIGHT:
            case Keys.NEXT:
                move(page());
                break;
            case Keys.OK:
                if (rep == 0) openSel();
                break;
            case Keys.BACK:
                if (rep == 0) up();
                break;
            default:
                break;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent ev) {
        int a = Keys.map(ev.getKeyCode());
        if (a == 0) return super.dispatchKeyEvent(ev);
        if (ev.getAction() == KeyEvent.ACTION_DOWN) handle(a, ev.getRepeatCount());
        return true;
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        int a = Keys.stick(e, axisLast);
        if (a != 0) {
            handle(a, 0);
            return true;
        }
        return super.onGenericMotionEvent(e);
    }
}
