package com.playhack5;

import android.graphics.Typeface;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Всплывающий список выбора поверх экрана; управляется клавишами (move/fire) и мышью/тачем. */
final class ListPanel {
    interface Pick {
        void on(int index);
    }

    private final FrameLayout host;
    private final Ui ui;
    private FrameLayout view;
    private List<String> labels = new ArrayList<>();
    private String head = "";
    private int sel, top;
    private Pick pick;

    ListPanel(FrameLayout host, Ui ui) {
        this.host = host;
        this.ui = ui;
    }

    boolean showing() {
        return view != null;
    }

    void show(String head, List<String> labels, int selected, Pick p) {
        hide();
        this.head = head;
        this.labels = labels;
        this.sel = Math.max(0, Math.min(selected, labels.size() - 1));
        this.top = 0;
        this.pick = p;
        build();
    }

    private void build() {
        if (view != null) host.removeView(view);
        view = new FrameLayout(host.getContext());
        view.setBackgroundColor(0xCC000814);
        view.setClickable(true);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hide();
            }
        });

        int n = labels.size();
        int vis = ui.compact ? 5 : 8;
        if (sel < top) top = sel;
        if (sel >= top + vis) top = sel - vis + 1;

        LinearLayout card = new LinearLayout(host.getContext());
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.rr(0xF0182544, 2 * ui.u));
        int p = (int) (2.2f * ui.u);
        card.setPadding(p, p, p, p);

        TextView h = new TextView(host.getContext());
        h.setText(n > vis ? head + "   " + (sel + 1) + "/" + n : head);
        h.setSingleLine(true);
        h.setEllipsize(TextUtils.TruncateAt.END);
        h.setTextColor(0xB3FFFFFF);
        h.setTextSize(TypedValue.COMPLEX_UNIT_PX, ui.px(3.8f, 12));
        h.setPadding((int) (2 * ui.u), 0, (int) (2 * ui.u), (int) ui.u);
        card.addView(h, new LinearLayout.LayoutParams(-1, -2));

        for (int i = top; i < Math.min(n, top + vis); i++) {
            TextView it = new TextView(host.getContext());
            it.setText(labels.get(i));
            it.setSingleLine(true);
            it.setEllipsize(TextUtils.TruncateAt.END);
            it.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            it.setTextSize(TypedValue.COMPLEX_UNIT_PX, ui.px(4.4f, 14));
            it.setPadding((int) (2 * ui.u), (int) (1.5f * ui.u), (int) (2 * ui.u), (int) (1.5f * ui.u));
            boolean on = i == sel;
            it.setBackground(on ? Ui.rr(0xFFFFFFFF, 1.2f * ui.u) : null);
            it.setTextColor(on ? 0xFF0A0F1E : 0xFFFFFFFF);
            final int ii = i;
            it.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sel = ii;
                    fire();
                }
            });
            card.addView(it, new LinearLayout.LayoutParams(-1, -2));
        }
        int cw = ui.compact ? (int) (ui.W * 0.7f) : Math.min((int) (ui.W * 0.8f), (int) Math.max(40 * ui.u, 230 * ui.d));
        view.addView(card, new FrameLayout.LayoutParams(cw, -2, Gravity.CENTER));
        host.addView(view, new FrameLayout.LayoutParams(-1, -1));
    }

    void move(int dir) {
        int n = labels.size();
        if (n == 0 || view == null) return;
        sel = (sel + dir + n) % n;
        build();
    }

    void fire() {
        Pick p = pick;
        int i = sel;
        hide();
        if (p != null) p.on(i);
    }

    void hide() {
        if (view != null) {
            host.removeView(view);
            view = null;
        }
    }
}
