package com.playhack5;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.View;

/**
 * Размеры интерфейса считаются от высоты экрана (u = 1% высоты).
 * На маленьких экранах (≈480×320) используются только относительные размеры,
 * чтобы всё гарантированно помещалось.
 */
final class Ui {
    final int W, H;
    final float u, d;
    final boolean compact;

    Ui(Activity a) {
        DisplayMetrics m = new DisplayMetrics();
        a.getWindowManager().getDefaultDisplay().getRealMetrics(m);
        W = Math.max(m.widthPixels, m.heightPixels);
        H = Math.min(m.widthPixels, m.heightPixels);
        d = m.density;
        u = H / 100f;
        compact = H <= 420;
    }

    /** uf — в процентах высоты; minDp — нижняя граница для больших экранов (на compact не применяется). */
    float px(float uf, float minDp) {
        return compact ? uf * u : Math.max(uf * u, minDp * d);
    }

    static GradientDrawable rr(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(r);
        return g;
    }

    @SuppressWarnings("deprecation")
    static void immersive(Activity a) {
        a.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
}
