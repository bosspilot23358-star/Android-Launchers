package com.playhack5;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Настройки (закрепления, время запуска) и список установленных приложений. */
final class Store {
    private final SharedPreferences sp;

    Store(Context c) {
        sp = c.getSharedPreferences("ph5", Context.MODE_PRIVATE);
    }

    private Set<String> set(String k) {
        return new HashSet<>(sp.getStringSet(k, new HashSet<String>()));
    }

    void setInGames(String pkg, boolean want) {
        Set<String> pinned = set("pinned");
        Set<String> unpinned = set("unpinned");
        if (want) {
            pinned.add(pkg);
            unpinned.remove(pkg);
        } else {
            pinned.remove(pkg);
            unpinned.add(pkg);
        }
        sp.edit().putStringSet("pinned", pinned).putStringSet("unpinned", unpinned).apply();
    }

    boolean lite(boolean def) {
        return sp.getBoolean("lite", def);
    }

    void setLite(boolean v) {
        sp.edit().putBoolean("lite", v).apply();
    }

    void touch(String pkg) {
        sp.edit().putLong("t:" + pkg, System.currentTimeMillis()).apply();
    }

    @SuppressWarnings("deprecation")
    private static boolean isGame(ApplicationInfo ai) {
        if (ai == null) return false;
        if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) return true;
        return (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
    }

    /** Все приложения, у которых есть запускаемая activity (обычная или Android TV). */
    List<Entry> load(Context c) {
        PackageManager pm = c.getPackageManager();
        Map<String, Entry> map = new LinkedHashMap<>();
        Set<String> pinned = set("pinned");
        Set<String> unpinned = set("unpinned");
        String[] cats = {Intent.CATEGORY_LAUNCHER, Intent.CATEGORY_LEANBACK_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            List<ResolveInfo> list = pm.queryIntentActivities(q, 0);
            for (ResolveInfo ri : list) {
                ActivityInfo ai = ri.activityInfo;
                if (ai == null) continue;
                String pkg = ai.packageName;
                if (pkg.equals(c.getPackageName()) || map.containsKey(pkg)) continue;
                Entry e = new Entry(Entry.APP);
                e.key = pkg;
                e.label = String.valueOf(ri.loadLabel(pm));
                e.intent = new Intent(Intent.ACTION_MAIN)
                        .addCategory(cat)
                        .setClassName(pkg, ai.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                e.game = (isGame(ai.applicationInfo) && !unpinned.contains(pkg)) || pinned.contains(pkg);
                e.last = sp.getLong("t:" + pkg, 0L);
                map.put(pkg, e);
            }
        }
        return new ArrayList<>(map.values());
    }
}
