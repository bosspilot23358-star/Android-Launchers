package com.playhack5;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;

import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Загрузка иконок в фоне + небольшой кэш (важно при 2 ГБ ОЗУ). */
final class IconCache {
    static final int DEFAULT_TINT = 0xFF0B2A5B;

    interface Cb {
        void done(String key, Bitmap bmp, int tint);
    }

    private final LruCache<String, Bitmap> cache;
    private final HashMap<String, Integer> tints = new HashMap<>(); // только главный поток
    private final ExecutorService ex = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final PackageManager pm;
    private final int size;

    IconCache(Context c, int tileSize, int maxBytes) {
        pm = c.getPackageManager();
        size = Math.min(tileSize, 256); // больше не нужно: GPU масштабирует при рисовании
        cache = new LruCache<String, Bitmap>(maxBytes) {
            @Override
            protected int sizeOf(String key, Bitmap b) {
                return b.getByteCount();
            }
        };
    }

    Bitmap peek(String key) {
        return cache.get(key);
    }

    int tint(String key) {
        Integer t = tints.get(key);
        return t == null ? DEFAULT_TINT : t;
    }

    void load(final Entry e, final Cb cb) {
        Bitmap hit = cache.get(e.key);
        if (hit != null) {
            cb.done(e.key, hit, tint(e.key));
            return;
        }
        ex.execute(new Runnable() {
            @Override
            public void run() {
                final Bitmap bmp = render(e);
                final int tint = tintOf(bmp);
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        cache.put(e.key, bmp);
                        tints.put(e.key, tint);
                        cb.done(e.key, bmp, tint);
                    }
                });
            }
        });
    }

    private Bitmap render(Entry e) {
        if (e.type == Entry.ACTION) return Glyphs.make(e.glyph, size);
        Drawable d;
        try {
            d = pm.getActivityIcon(e.intent);
        } catch (Exception ex) {
            d = pm.getDefaultActivityIcon();
        }
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        cv.drawColor(0xFF1B2540);
        int pad = 0;
        // Адаптивные иконки рисуются с запасом 18% по краям — обрезаем до «безопасной» зоны.
        if (Build.VERSION.SDK_INT >= 26 && d.getClass().getSimpleName().equals("AdaptiveIconDrawable")) {
            pad = size / 4;
        }
        d.setBounds(-pad, -pad, size + pad, size + pad);
        d.draw(cv);
        return b;
    }

    /** Средний цвет иконки → тёмный насыщенный оттенок для фона. */
    static int tintOf(Bitmap bmp) {
        Bitmap s = Bitmap.createScaledBitmap(bmp, 8, 8, true);
        long r = 0, g = 0, b = 0, n = 0;
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                int p = s.getPixel(x, y);
                if (Color.alpha(p) < 128) continue;
                r += Color.red(p);
                g += Color.green(p);
                b += Color.blue(p);
                n++;
            }
        }
        if (s != bmp) s.recycle();
        if (n == 0) return DEFAULT_TINT;
        float[] hsv = new float[3];
        Color.RGBToHSV((int) (r / n), (int) (g / n), (int) (b / n), hsv);
        if (hsv[1] < 0.22f) {
            hsv[0] = 215f;
            hsv[1] = 0.8f;
        } else {
            hsv[1] = Math.max(0.55f, Math.min(1f, hsv[1]));
        }
        hsv[2] = 0.5f;
        return Color.HSVToColor(hsv);
    }
}
