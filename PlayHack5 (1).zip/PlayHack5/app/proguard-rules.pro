# libVLC вызывает Java из нативного кода — классы нельзя переименовывать/удалять.
-keep class org.videolan.libvlc.** { *; }
-keep class org.videolan.** { *; }
-dontwarn org.videolan.**
