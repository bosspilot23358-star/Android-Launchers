Papka dlya faylov, kotorye skript sborki skachivaet sam (ili kotorye mozhno polozhit' vruchnuyu,
esli avtomaticheskaya zagruzka ne prohodit):

  libvlc-all-3.6.2.aar
      https://repo1.maven.org/maven2/org/videolan/android/libvlc-all/3.6.2/libvlc-all-3.6.2.aar

  commandlinetools-win-11076708_latest.zip   (dlya Linux: commandlinetools-linux-..., dlya Mac: ...-mac-...)
      https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip

Skachajte v brauzere (s VPN), polozhite syuda - i zapustite sborku snova: build.bat
