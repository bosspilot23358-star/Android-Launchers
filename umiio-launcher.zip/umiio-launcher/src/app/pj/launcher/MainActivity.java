package app.pj.launcher;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Apple TV-style home screen for weak Android projectors.
 *
 * Performance rules used here:
 *  - every card is pre-rendered ONCE into a single bitmap on a background thread,
 *    so drawing a card is one drawBitmap call (no per-frame layout, clipping, blur);
 *  - the row scrolls with translationX (RenderNode property, no relayout / redraw of children);
 *  - focus animation = scale + translationZ via ViewPropertyAnimator (GPU only);
 *  - the backdrop is one cached hardware layer, only repainted while the tint cross-fades.
 */
public class MainActivity extends Activity {

    private static final float FOCUS_SCALE = 1.12f;
    private static final int DEFAULT_TINT = 0xFF35507F;

    static final class App {
        String key;
        String pkg;
        ComponentName cn;
        ResolveInfo ri;
        CharSequence label;
        ImageView card;
        Bitmap bmp;
        int tint = DEFAULT_TINT;
        boolean queued;
    }

    static final class Found {
        ResolveInfo ri;
        String key;
        String label;
    }

    static final class Rendered {
        Bitmap bmp;
        int tint;
    }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final HashMap<String, App> cache = new HashMap<>();
    private ArrayList<App> apps = new ArrayList<>();
    private final DecelerateInterpolator decel = new DecelerateInterpolator(1.8f);

    private int W, H, cardW, cardH, gap, cardR;
    private FrameLayout root, content, viewport;
    private LinearLayout row;
    private GradientDrawable glow;
    private TextView label;
    private int curTint = DEFAULT_TINT;
    private ValueAnimator tintAnim;
    private String focusedKey;
    private FrameLayout overlay;
    private App overlayApp;
    private boolean receiverOn;
    private boolean firstStart = true;
    private ViewOutlineProvider outlineProvider;

    private final Runnable reloadTask = new Runnable() {
        @Override public void run() { reload(); }
    };

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            ui.removeCallbacks(reloadTask);
            ui.postDelayed(reloadTask, 500);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        W = Math.max(dm.widthPixels, dm.heightPixels);
        H = Math.min(dm.widthPixels, dm.heightPixels);
        cardW = (int) (W * 0.18f);
        cardH = cardW * 9 / 16;
        gap = (int) (cardW * 0.12f);
        cardR = (int) (cardH * 0.12f);

        outlineProvider = new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), cardR);
                o.setAlpha(1f);
            }
        };

        buildUi();
        getWindow().setBackgroundDrawable(null); // root is opaque: avoid double overdraw
        reload();
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_REPLACED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);
        receiverOn = true;
        if (!firstStart) reload(); // may have missed changes while stopped
        firstStart = false;
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (receiverOn) {
            try { unregisterReceiver(pkgReceiver); } catch (IllegalArgumentException ignored) { }
            receiverOn = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Home pressed while we are already running: go back to the first tile
        if (overlay != null) closeOptions();
        if (!apps.isEmpty() && apps.get(0).card != null) apps.get(0).card.requestFocusFromTouch();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public void onBackPressed() {
        if (overlay != null) closeOptions();
        // launcher: Back does nothing otherwise
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        if ((keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_INFO)
                && e.getRepeatCount() == 0 && overlay == null) {
            View f = getCurrentFocus();
            if (f != null && f.getTag() instanceof App) {
                showOptions((App) f.getTag());
                return true;
            }
        }
        return super.onKeyDown(keyCode, e);
    }

    // ------------------------------------------------------------------ UI

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF05070D);

        // soft colored backdrop (one radial gradient, tinted by the focused app)
        View glowView = new View(this);
        glow = new GradientDrawable();
        glow.setShape(GradientDrawable.RECTANGLE);
        glow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        glow.setGradientCenter(0.18f, 0f);
        glow.setGradientRadius(W * 0.95f);
        glow.setColors(new int[]{0xFFFFFFFF, 0x00FFFFFF});
        glow.setTintMode(PorterDuff.Mode.SRC_IN);
        glow.setTint(backdrop(curTint));
        glowView.setBackground(glow);
        glowView.setLayerType(View.LAYER_TYPE_HARDWARE, null); // cached texture between color changes
        root.addView(glowView, new FrameLayout.LayoutParams(-1, -1));

        content = new FrameLayout(this);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        // hero: big clock + date
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        TextClock time = new TextClock(this);
        time.setFormat24Hour("H:mm");
        time.setFormat12Hour("H:mm");
        time.setTextColor(Color.WHITE);
        time.setTextSize(TypedValue.COMPLEX_UNIT_PX, H * 0.13f);
        time.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        time.setIncludeFontPadding(false);
        TextClock date = new TextClock(this);
        date.setFormat24Hour("EEEE, d MMMM");
        date.setFormat12Hour("EEEE, d MMMM");
        date.setTextColor(0xB3FFFFFF);
        date.setTextSize(TypedValue.COMPLEX_UNIT_PX, H * 0.036f);
        date.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        hero.addView(time);
        hero.addView(date);
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        hlp.leftMargin = (int) (W * 0.06f);
        hlp.topMargin = (int) (H * 0.07f);
        content.addView(hero, hlp);

        // top-right pills
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        addPill(bar, "Wi-Fi", Settings.ACTION_WIFI_SETTINGS);
        addPill(bar, "Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS);
        addPill(bar, "Настройки", Settings.ACTION_SETTINGS);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        blp.rightMargin = (int) (W * 0.06f);
        blp.topMargin = (int) (H * 0.07f);
        content.addView(bar, blp);

        // the row of cards; it is moved with translationX so the focused card stays centered
        viewport = new FrameLayout(this);
        viewport.setClipChildren(false);
        row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setClipChildren(false);
        int pad = (W - cardW) / 2;
        row.setPadding(pad, 0, pad, 0);
        viewport.addView(row, new FrameLayout.LayoutParams(W, -1));
        int rowTop = (int) (H * 0.40f);
        FrameLayout.LayoutParams vlp = new FrameLayout.LayoutParams(-1, (int) (cardH * 1.5f), Gravity.TOP);
        vlp.topMargin = rowTop;
        content.addView(viewport, vlp);

        // label under the focused card (always at screen center)
        label = new TextView(this);
        label.setTextColor(Color.WHITE);
        label.setTextSize(TypedValue.COMPLEX_UNIT_PX, H * 0.036f);
        label.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        label.setGravity(Gravity.CENTER);
        label.setSingleLine(true);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        label.setPadding((int) (W * 0.2f), 0, (int) (W * 0.2f), 0);
        FrameLayout.LayoutParams llp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        llp.topMargin = rowTop + (int) (cardH * 1.24f);
        content.addView(label, llp);

        setContentView(root);
    }

    private void addPill(LinearLayout bar, String text, final String action) {
        final TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, H * 0.028f);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        int ph = (int) (H * 0.035f), pv = (int) (H * 0.016f);
        t.setPadding(ph, pv, ph, pv);
        final GradientDrawable idle = round(0x2EFFFFFF, 9999);
        final GradientDrawable foc = round(0xFFFFFFFF, 9999);
        t.setBackground(idle);
        t.setFocusable(true);
        t.setClickable(true);
        t.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean has) {
                t.setBackground(has ? foc : idle);
                t.setTextColor(has ? 0xFF111318 : Color.WHITE);
                float s = has ? 1.08f : 1f;
                v.animate().scaleX(s).scaleY(s).setDuration(140).start();
            }
        });
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openSettings(action); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = (int) (H * 0.02f);
        bar.addView(t, lp);
    }

    private ImageView makeCard(final App a) {
        ImageView v = new ImageView(this);
        v.setScaleType(ImageView.ScaleType.FIT_XY);
        v.setImageDrawable(round(0xFF1E222B, cardR));
        v.setTag(a);
        v.setFocusable(true);
        v.setClickable(true);
        v.setLongClickable(true);
        v.setOutlineProvider(outlineProvider);
        v.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View x) { launch(a); }
        });
        v.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View x) { showOptions(a); return true; }
        });
        v.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View x, boolean has) { onCardFocus(a, x, has); }
        });
        return v;
    }

    private void onCardFocus(App a, View v, boolean has) {
        if (has) {
            focusedKey = a.key;
            v.animate().scaleX(FOCUS_SCALE).scaleY(FOCUS_SCALE).translationZ(H * 0.03f)
                    .setDuration(170).setInterpolator(decel).start();
            label.setText(a.label);
            centerOn(apps.indexOf(a), true);
            animateTint(a.tint);
        } else {
            v.animate().scaleX(1f).scaleY(1f).translationZ(0f)
                    .setDuration(140).setInterpolator(decel).start();
        }
    }

    private void centerOn(int index, boolean animate) {
        if (index < 0) return;
        float target = -index * (float) (cardW + gap);
        if (animate) {
            row.animate().translationX(target).setDuration(260).setInterpolator(decel).start();
        } else {
            row.animate().cancel();
            row.setTranslationX(target);
        }
    }

    private void animateTint(int to) {
        if (tintAnim != null) tintAnim.cancel();
        tintAnim = ValueAnimator.ofArgb(curTint, to);
        tintAnim.setDuration(380);
        tintAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator va) {
                curTint = (Integer) va.getAnimatedValue();
                glow.setTint(backdrop(curTint));
            }
        });
        tintAnim.start();
    }

    // ------------------------------------------------------------------ app list

    private void reload() {
        io.execute(new Runnable() {
            @Override public void run() {
                final ArrayList<Found> found = scan();
                runOnUiThread(new Runnable() {
                    @Override public void run() { applyList(found); }
                });
            }
        });
    }

    private ArrayList<Found> scan() {
        PackageManager pm = getPackageManager();
        ArrayList<Found> out = new ArrayList<>();
        HashSet<String> seenPkg = new HashSet<>();
        seenPkg.add(getPackageName());
        // leanback first: those apps ship a proper 16:9 banner
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String c : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(c);
            List<ResolveInfo> l = pm.queryIntentActivities(q, 0);
            for (ResolveInfo ri : l) {
                ActivityInfo ai = ri.activityInfo;
                if (!seenPkg.add(ai.packageName)) continue;
                Found f = new Found();
                f.ri = ri;
                f.key = ai.packageName + "/" + ai.name;
                f.label = String.valueOf(ri.loadLabel(pm));
                out.add(f);
            }
        }
        return out;
    }

    private void applyList(ArrayList<Found> found) {
        HashSet<String> live = new HashSet<>();
        ArrayList<App> next = new ArrayList<>();
        for (Found f : found) {
            live.add(f.key);
            App a = cache.get(f.key);
            if (a == null) {
                a = new App();
                a.key = f.key;
                a.ri = f.ri;
                a.pkg = f.ri.activityInfo.packageName;
                a.cn = new ComponentName(a.pkg, f.ri.activityInfo.name);
                cache.put(f.key, a);
            }
            a.label = f.label;
            next.add(a);
        }
        cache.keySet().retainAll(live);

        final HashMap<String, Integer> pos = new HashMap<>();
        String saved = getSharedPreferences("home", MODE_PRIVATE).getString("order", "");
        if (saved.length() > 0) {
            String[] parts = saved.split("\\|");
            for (int i = 0; i < parts.length; i++) pos.put(parts[i], i);
        }
        Collections.sort(next, new java.util.Comparator<App>() {
            @Override public int compare(App x, App y) {
                Integer px = pos.get(x.key), py = pos.get(y.key);
                int ix = px == null ? Integer.MAX_VALUE : px;
                int iy = py == null ? Integer.MAX_VALUE : py;
                if (ix != iy) return ix < iy ? -1 : 1;
                return x.label.toString().compareToIgnoreCase(y.label.toString());
            }
        });

        boolean same = next.size() == apps.size();
        for (int i = 0; same && i < next.size(); i++) same = next.get(i) == apps.get(i);
        apps = next;
        if (!same || row.getChildCount() != apps.size()) rebuildRow();
    }

    private void rebuildRow() {
        row.removeAllViews();
        int n = apps.size();
        int total = (W - cardW) + n * cardW + Math.max(0, n - 1) * gap;
        viewport.updateViewLayout(row, new FrameLayout.LayoutParams(Math.max(total, W), -1));
        for (int i = 0; i < n; i++) {
            App a = apps.get(i);
            if (a.card == null) a.card = makeCard(a);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cardW, cardH);
            lp.rightMargin = i < n - 1 ? gap : 0;
            row.addView(a.card, lp);
            enqueueRender(a);
        }
        if (n == 0 || overlay != null) return;
        int idx = 0;
        for (int i = 0; i < n; i++) if (apps.get(i).key.equals(focusedKey)) idx = i;
        centerOn(idx, false);
        label.setText(apps.get(idx).label);
        apps.get(idx).card.requestFocusFromTouch();
    }

    private void saveOrder() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < apps.size(); i++) {
            if (i > 0) sb.append('|');
            sb.append(apps.get(i).key);
        }
        getSharedPreferences("home", MODE_PRIVATE).edit().putString("order", sb.toString()).apply();
    }

    // ------------------------------------------------------------------ card rendering (background thread)

    private void enqueueRender(final App a) {
        if (a.bmp != null || a.queued) return;
        a.queued = true;
        io.execute(new Runnable() {
            @Override public void run() {
                final Rendered r = renderCard(a);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        a.queued = false;
                        if (r == null) return;
                        a.bmp = r.bmp;
                        a.tint = r.tint;
                        if (a.card != null) a.card.setImageBitmap(r.bmp);
                        if (a.key.equals(focusedKey)) animateTint(a.tint);
                    }
                });
            }
        });
    }

    private Rendered renderCard(App a) {
        try {
            PackageManager pm = getPackageManager();
            ActivityInfo ai = a.ri.activityInfo;
            Drawable banner = null;
            try { banner = ai.loadBanner(pm); } catch (Throwable ignored) { }
            Drawable src = banner != null ? banner : ai.loadIcon(pm);
            if (src == null) return null;

            int tint = sampleColor(src);

            Bitmap content = Bitmap.createBitmap(cardW, cardH, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(content);
            if (banner != null) {
                drawCover(c, banner, cardW, cardH);
            } else {
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setShader(new LinearGradient(0, 0, 0, cardH, shade(tint, 1.18f), shade(tint, 0.55f),
                        Shader.TileMode.CLAMP));
                c.drawRect(0, 0, cardW, cardH, p);
                int s = (int) (cardH * 0.60f);
                src.setBounds((cardW - s) / 2, (cardH - s) / 2, (cardW + s) / 2, (cardH + s) / 2);
                src.draw(c);
            }

            // round the corners once, with anti-aliasing
            Bitmap out = Bitmap.createBitmap(cardW, cardH, Bitmap.Config.ARGB_8888);
            Canvas oc = new Canvas(out);
            Paint rp = new Paint(Paint.ANTI_ALIAS_FLAG);
            rp.setShader(new BitmapShader(content, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            oc.drawRoundRect(new RectF(0, 0, cardW, cardH), cardR, cardR, rp);
            content.recycle();

            Rendered r = new Rendered();
            r.bmp = out;
            r.tint = tint;
            return r;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void drawCover(Canvas c, Drawable d, int w, int h) {
        int iw = d.getIntrinsicWidth(), ih = d.getIntrinsicHeight();
        if (iw <= 0 || ih <= 0) {
            d.setBounds(0, 0, w, h);
            d.draw(c);
            return;
        }
        float s = Math.max(w / (float) iw, h / (float) ih);
        c.save();
        c.translate((w - iw * s) / 2f, (h - ih * s) / 2f);
        c.scale(s, s);
        d.setBounds(0, 0, iw, ih);
        d.draw(c);
        c.restore();
    }

    /** Average color of the drawable weighted by saturation, normalized to a pleasant card color. */
    private static int sampleColor(Drawable d) {
        final int n = 24;
        Bitmap s = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(s);
        d.setBounds(0, 0, n, n);
        d.draw(c);
        int[] px = new int[n * n];
        s.getPixels(px, 0, n, 0, 0, n, n);
        s.recycle();
        float[] hsv = new float[3];
        double r = 0, g = 0, b = 0, ws = 0;
        for (int p : px) {
            if (Color.alpha(p) < 128) continue;
            Color.colorToHSV(p, hsv);
            double w = hsv[1] * hsv[2] + 0.03;
            r += Color.red(p) * w;
            g += Color.green(p) * w;
            b += Color.blue(p) * w;
            ws += w;
        }
        if (ws <= 0) return DEFAULT_TINT;
        int col = Color.rgb((int) (r / ws), (int) (g / ws), (int) (b / ws));
        Color.colorToHSV(col, hsv);
        if (hsv[1] < 0.18f) return 0xFF3A3F4B; // white/grey logos -> slate card
        hsv[1] = Math.min(0.85f, hsv[1]);
        hsv[2] = Math.max(0.45f, Math.min(0.85f, hsv[2]));
        return Color.HSVToColor(hsv);
    }

    private static int shade(int c, float f) {
        int r = Math.min(255, (int) (Color.red(c) * f));
        int g = Math.min(255, (int) (Color.green(c) * f));
        int b = Math.min(255, (int) (Color.blue(c) * f));
        return Color.rgb(r, g, b);
    }

    private static int backdrop(int tint) {
        return shade(tint, 0.62f);
    }

    private static GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(r);
        return g;
    }

    // ------------------------------------------------------------------ actions

    private void launch(App a) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.setComponent(a.cn);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
        } catch (Throwable t) {
            Toast.makeText(this, "Не удалось открыть: " + a.label, Toast.LENGTH_SHORT).show();
        }
    }

    private void openSettings(String action) {
        try {
            startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Throwable ignored) { }
        }
    }

    private void move(App a, int dir) {
        int i = apps.indexOf(a), j = i + dir;
        if (i < 0 || j < 0 || j >= apps.size()) return;
        Collections.swap(apps, i, j);
        saveOrder();
        focusedKey = a.key;
        rebuildRow();
    }

    // ------------------------------------------------------------------ options overlay (long-press OK / Menu)

    private void showOptions(final App a) {
        if (overlay != null) return;
        overlayApp = a;
        overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0xD005070D);
        overlay.setClickable(true);
        overlay.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeOptions(); }
        });

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(round(0xFF22252D, H * 0.03f));
        int p = (int) (H * 0.03f);
        panel.setPadding(p, p, p, p);

        TextView title = new TextView(this);
        title.setText(a.label);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, H * 0.038f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        title.setSingleLine(true);
        title.setPadding(p / 2, 0, p / 2, p / 2);
        panel.addView(title);

        final int idx = apps.indexOf(a);
        addOption(panel, "Открыть", new Runnable() { @Override public void run() { launch(a); } });
        if (idx > 0) addOption(panel, "Переместить влево",
                new Runnable() { @Override public void run() { move(a, -1); } });
        if (idx >= 0 && idx < apps.size() - 1) addOption(panel, "Переместить вправо",
                new Runnable() { @Override public void run() { move(a, 1); } });
        addOption(panel, "О приложении", new Runnable() {
            @Override public void run() {
                try {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", a.pkg, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (Throwable ignored) { }
            }
        });
        boolean system = (a.ri.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
        if (!system) addOption(panel, "Удалить", new Runnable() {
            @Override public void run() {
                try {
                    startActivity(new Intent(Intent.ACTION_DELETE, Uri.fromParts("package", a.pkg, null))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (Throwable ignored) { }
            }
        });

        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams((int) (W * 0.30f), -2, Gravity.CENTER);
        overlay.addView(panel, plp);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        content.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        panel.getChildAt(1).requestFocusFromTouch();
    }

    private void addOption(LinearLayout panel, String text, final Runnable action) {
        final TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, H * 0.032f);
        t.setTextColor(0xFFFFFFFF);
        int ph = (int) (H * 0.025f), pv = (int) (H * 0.018f);
        t.setPadding(ph, pv, ph, pv);
        final GradientDrawable idle = round(0x00FFFFFF, H * 0.02f);
        final GradientDrawable foc = round(0xFFFFFFFF, H * 0.02f);
        t.setBackground(idle);
        t.setFocusable(true);
        t.setClickable(true);
        t.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean has) {
                t.setBackground(has ? foc : idle);
                t.setTextColor(has ? 0xFF111318 : 0xFFFFFFFF);
            }
        });
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                closeOptions();
                action.run();
            }
        });
        panel.addView(t, new LinearLayout.LayoutParams(-1, -2));
    }

    private void closeOptions() {
        if (overlay == null) return;
        root.removeView(overlay);
        overlay = null;
        content.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        if (overlayApp != null && overlayApp.card != null) overlayApp.card.requestFocusFromTouch();
        overlayApp = null;
    }
}
